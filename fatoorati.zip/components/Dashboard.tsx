import React, { useState, useEffect } from 'react';
import type { View, DashboardStats, Invoice } from '../types';
import { getDashboardStats, getInvoices } from '../services/supabaseService';
import StatCard from './StatCard';
import { DollarIcon, DocumentSentIcon, ClockIcon, ExclamationIcon, PencilIcon } from './Icons';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';

interface DashboardProps {
  setView: (view: View) => void;
  onEditInvoice: (id: string) => void;
}

const getStatusChipClass = (status: Invoice['status']) => {
  switch (status) {
    case 'paid':
      return 'bg-green-500/20 text-green-400';
    case 'overdue':
      return 'bg-red-500/20 text-red-400';
    case 'draft':
      return 'bg-slate-500/20 text-slate-400';
    case 'pending':
    default:
      return 'bg-yellow-500/20 text-yellow-400';
  }
};

const Dashboard: React.FC<DashboardProps> = ({ setView, onEditInvoice }) => {
  const [stats, setStats] = useState<DashboardStats | null>(null);
  const [recentInvoices, setRecentInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const { language, formatCurrency } = useSettings();
  const t = translations[language];

  useEffect(() => {
    const fetchData = async () => {
      try {
        setLoading(true);
        const [statsData, allInvoices] = await Promise.all([
            getDashboardStats(),
            getInvoices()
        ]);
        setStats(statsData);
        setRecentInvoices(allInvoices.slice(0, 5));
      } catch (error) {
        console.error("Failed to fetch dashboard data", error);
      } finally {
        setLoading(false);
      }
    };
    fetchData();
  }, []);
  

  if (loading) {
    return <div className="p-8 text-center text-[--text-tertiary]">{t.dashboard.loading}</div>;
  }

  return (
    <div className="p-4 md:p-8">
      <h1 className="text-3xl md:text-4xl font-bold text-[--text-primary] mb-2">{t.dashboard.title}</h1>
      
      {/* Stats Cards */}
      <div className="grid grid-cols-1 sm:grid-cols-2 lg:grid-cols-4 gap-6 mt-8">
        <StatCard 
          icon={<DollarIcon />} 
          title={t.dashboard.stats.totalRevenue.title} 
          value={formatCurrency(stats?.totalRevenue ?? 0)}
          subtitle={t.dashboard.stats.totalRevenue.subtitle} 
        />
        <StatCard 
          icon={<DocumentSentIcon />} 
          title={t.dashboard.stats.sentInvoices.title} 
          value={stats?.sentCount ?? 0}
          subtitle={t.dashboard.stats.sentInvoices.subtitle}
        />
        <StatCard 
          icon={<ClockIcon />} 
          title={t.dashboard.stats.dueSoon.title}
          value={stats?.dueSoonCount ?? 0}
          subtitle={t.dashboard.stats.dueSoon.subtitle}
        />
        <StatCard 
          icon={<ExclamationIcon className="text-red-400" />} 
          title={t.dashboard.stats.overdue.title} 
          value={stats?.overdueCount ?? 0}
          subtitle={t.dashboard.stats.overdue.subtitle}
          valueColor="text-red-400"
        />
      </div>

      {/* Recent Invoices */}
      <div className="mt-12">
        <h2 className="text-2xl font-bold text-[--text-primary]">{t.dashboard.recentInvoices.title}</h2>
        <p className="text-[--text-tertiary] mt-1">{t.dashboard.recentInvoices.subtitle}</p>
        
        <div className="bg-[--bg-secondary] rounded-lg shadow-2xl mt-6 overflow-hidden">
           {recentInvoices.length > 0 ? (
           <>
            {/* Table for larger screens */}
            <div className="overflow-x-auto hidden md:block">
              <table className={`w-full ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                <thead className="border-b border-[--border-primary] text-[--text-tertiary] text-sm">
                  <tr>
                    <th className="p-4 font-medium">{t.dashboard.recentInvoices.table.invoice}</th>
                    <th className="p-4 font-medium">{t.dashboard.recentInvoices.table.client}</th>
                    <th className="p-4 font-medium">{t.dashboard.recentInvoices.table.status}</th>
                    <th className="p-4 font-medium">{t.dashboard.recentInvoices.table.date}</th>
                    <th className="p-4 font-medium">{t.dashboard.recentInvoices.table.amount}</th>
                  </tr>
                </thead>
                <tbody>
                  {recentInvoices.map(invoice => (
                    <tr key={invoice.id} className="border-b border-[--border-primary] last:border-b-0 hover:bg-[--bg-tertiary]/50">
                      <td className="p-4 text-[--text-secondary]">{invoice.invoiceNumber}</td>
                      <td className="p-4 text-[--text-primary]">{invoice.clientName}</td>
                       <td className="p-4">
                        <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getStatusChipClass(invoice.status)}`}>
                          {t.invoiceStatus[invoice.status]}
                        </span>
                      </td>
                      <td className="p-4 text-[--text-secondary]">{invoice.date}</td>
                      <td className="p-4 font-bold text-[--text-primary]">{formatCurrency(invoice.amount)}</td>
                    </tr>
                  ))}
                </tbody>
              </table>
            </div>
            {/* Cards for mobile screens */}
            <div className="block md:hidden p-4 space-y-4">
               {recentInvoices.map(invoice => (
                <div key={invoice.id} className="bg-[--bg-tertiary]/50 rounded-lg p-4 shadow-md">
                    <div className="flex justify-between items-start">
                        <div>
                            <p className="font-bold text-[--text-primary]">{invoice.clientName}</p>
                            <p className="text-sm text-[--text-tertiary]">{invoice.invoiceNumber}</p>
                        </div>
                         <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getStatusChipClass(invoice.status)}`}>
                          {t.invoiceStatus[invoice.status]}
                        </span>
                    </div>
                    <div className="flex justify-between items-end mt-4">
                        <div>
                            <p className="text-lg font-bold text-[--text-primary]">{formatCurrency(invoice.amount)}</p>
                            <p className="text-sm text-[--text-tertiary]">{t.invoiceList.table.dueDate}: {invoice.dueDate}</p>
                        </div>
                        <button
                            onClick={() => onEditInvoice(invoice.id)}
                            className="p-2 rounded-full text-[--text-secondary] hover:bg-[--bg-tertiary] hover:text-[--text-primary] transition-colors focus:outline-none focus:ring-2 focus:ring-[--primary-500]"
                            title={t.invoiceList.actions.edit}
                            aria-label={t.invoiceList.actions.edit}
                        >
                            <PencilIcon className="w-5 h-5" />
                        </button>
                    </div>
                </div>
              ))}
            </div>
           </>
           ) : (
            <div className="text-center p-8 text-[--text-tertiary]">
              {t.dashboard.recentInvoices.noInvoices}
            </div>
           )}
        </div>
      </div>
    </div>
  );
};

export default Dashboard;
import React, { useState, useEffect, useCallback, useMemo } from 'react';
import { getInvoices, deleteInvoice } from '../services/supabaseService';
import type { Invoice, View, InvoiceStatus } from '../types';
import { TrashIcon, PlusIcon, PencilIcon, PrinterIcon, DownloadIcon, DocumentTextIcon, FlagIcon } from './Icons';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';
import ConfirmationModal from './ConfirmationModal';
import ComplaintModal from './ComplaintModal';


interface InvoiceListProps {
  setView: (view: View) => void;
  onEdit: (id: string) => void;
}

type InvoiceStatusFilter = InvoiceStatus | 'all';

const getStatusChipClass = (status: InvoiceStatus) => {
  switch (status) {
    case 'paid':
      return 'bg-green-500/20 text-green-400';
    case 'overdue':
      return 'bg-red-500/20 text-red-400';
    case 'draft':
      return 'bg-slate-500/20 text-slate-400';
    case 'pending':
    default:
      return 'bg-yellow-500/20 text-yellow-400';
  }
};


const InvoiceList: React.FC<InvoiceListProps> = ({ setView, onEdit }) => {
  const [invoices, setInvoices] = useState<Invoice[]>([]);
  const [loading, setLoading] = useState(true);
  const [error, setError] = useState('');
  const [activeFilter, setActiveFilter] = useState<InvoiceStatusFilter>('all');
  const [invoiceToDelete, setInvoiceToDelete] = useState<string | null>(null);
  const [isComplaintModalOpen, setIsComplaintModalOpen] = useState(false);
  
  const { language, currency, theme, primaryColor, formatCurrency } = useSettings();
  const t = translations[language];
  
  const filterTabs: InvoiceStatusFilter[] = ['all', 'pending', 'paid', 'overdue', 'draft'];


  const fetchInvoices = useCallback(async () => {
    try {
      setLoading(true);
      setError('');
      const data = await getInvoices();
      setInvoices(data);
    } catch (err) {
      setError(t.invoiceList.errors.fetch);
      console.error(err);
    } finally {
      setLoading(false);
    }
  }, [t]);

  useEffect(() => {
    fetchInvoices();
  }, [fetchInvoices]);

  const filteredInvoices = useMemo(() => {
    if (activeFilter === 'all') {
        return invoices;
    }
    return invoices.filter(invoice => invoice.status === activeFilter);
  }, [invoices, activeFilter]);

  const handleConfirmDelete = async () => {
    if (!invoiceToDelete) return;
    
    const idToDelete = invoiceToDelete;
    setInvoiceToDelete(null); // Close modal

    // Optimistically update the UI using a functional update for safety.
    setInvoices(prevInvoices => prevInvoices.filter(invoice => invoice.id !== idToDelete));

    try {
      // Attempt to delete the invoice from persistence.
      await deleteInvoice(idToDelete);
    } catch (err) {
      // If deletion fails, set an error message and re-fetch from the source
      // of truth to ensure UI consistency.
      setError(t.invoiceList.errors.delete);
      fetchInvoices(); // Re-sync state with storage on error.
      console.error(err);
    }
  };
  
  const getInvoiceHTML = (invoice: Invoice): string => {
    const isDark = theme === 'dark';
    const accentColors: Record<string, string> = {
        blue: '#3b82f6',
        green: '#22c55e',
        purple: '#8b5cf6',
        orange: '#f97316',
        red: '#ef4444',
        teal: '#14b8a6'
    };
    const accent = accentColors[primaryColor] || '#3b82f6';

    return `
      <!DOCTYPE html>
      <html lang="${language}" dir="${language === 'ar' ? 'rtl' : 'ltr'}">
      <head>
          <meta charset="UTF-8">
          <title>${t.invoicePrint.title} ${invoice.invoiceNumber}</title>
          <link href="https://fonts.googleapis.com/css2?family=Cairo:wght@400;700&display=swap" rel="stylesheet">
          <style>
              body { font-family: 'Cairo', sans-serif; direction: ${language === 'ar' ? 'rtl' : 'ltr'}; text-align: ${language === 'ar' ? 'right' : 'left'}; margin: 0; padding: 2rem; background-color: ${isDark ? '#030712' : '#fff'}; color: ${isDark ? '#f9fafb' : '#1f2937'}; }
              .invoice-box { max-width: 800px; margin: auto; padding: 30px; border: 1px solid ${isDark ? '#374151' : '#eee'}; box-shadow: 0 0 10px rgba(0, 0, 0, 0.1); font-size: 16px; line-height: 24px; background-color: ${isDark ? '#1f2937' : '#fff'}; }
              .header { text-align: center; margin-bottom: 40px; }
              .header h1 { font-size: 2.5em; color: ${accent}; }
              .details-grid { display: grid; grid-template-columns: 1fr 1fr; gap: 20px; margin-bottom: 40px; border-bottom: 2px solid ${isDark ? '#374151' : '#f3f4f6'}; padding-bottom: 20px;}
              .details-grid div h3 { font-size: 1em; color: ${isDark ? '#9ca3af' : '#6b7280'}; margin-bottom: 5px; }
              .details-grid div p { font-size: 1.1em; font-weight: bold; margin: 0; }
              .items-table { width: 100%; text-align: ${language === 'ar' ? 'right' : 'left'}; border-collapse: collapse; margin-top: 20px; }
              .items-table thead tr { background-color: ${accent}; color: #fff; }
              .items-table th, .items-table td { padding: 12px 15px; border-bottom: 1px solid ${isDark ? '#374151' : '#ddd'}; }
              .total { text-align: ${language === 'ar' ? 'left' : 'right'}; margin-top: 30px; font-size: 1.3em; font-weight: bold; }
              @media print {
                  body { -webkit-print-color-adjust: exact; print-color-adjust: exact; padding: 0; }
                  .invoice-box { box-shadow: none; border: none; margin: 0; max-width: 100%; }
              }
          </style>
      </head>
      <body>
          <div class="invoice-box">
              <div class="header"><h1>${t.invoicePrint.title}</h1></div>
              <div class="details-grid">
                <div><h3>${t.invoicePrint.to}</h3><p>${invoice.clientName}</p>${invoice.clientEmail ? `<p style="font-size: 0.9em; color: ${isDark ? '#9ca3af' : '#6b7280'};">${invoice.clientEmail}</p>` : ''}</div>
                <div><h3>${t.invoicePrint.invoiceNo}</h3><p>${invoice.invoiceNumber}</p></div>
                <div><h3>${t.invoicePrint.issueDate}</h3><p>${invoice.date}</p></div>
                <div><h3>${t.invoicePrint.dueDate}</h3><p>${invoice.dueDate}</p></div>
              </div>
              <table class="items-table">
                  <thead><tr><th>${t.invoicePrint.description}</th><th style="text-align: ${language === 'ar' ? 'left' : 'right'};">${t.invoicePrint.amount}</th></tr></thead>
                  <tbody><tr><td>${t.invoicePrint.serviceDesc}</td><td style="text-align: ${language === 'ar' ? 'left' : 'right'};">${formatCurrency(invoice.amount)}</td></tr></tbody>
              </table>
              <div class="total">${t.invoicePrint.total}: ${formatCurrency(invoice.amount)}</div>
          </div>
      </body>
      </html>
    `;
  };

  const handlePrint = (invoice: Invoice) => {
    const printContent = getInvoiceHTML(invoice);
    const printWindow = window.open('', '_blank');
    if (printWindow) {
        printWindow.document.write(printContent);
        printWindow.document.close();
        printWindow.focus();
        setTimeout(() => {
            printWindow.print();
            printWindow.close();
        }, 250); // Timeout for resources to load
    } else {
        alert(t.invoiceList.errors.popup);
    }
  };

  const handleDownload = (invoice: Invoice) => {
    const htmlContent = getInvoiceHTML(invoice);
    const blob = new Blob([htmlContent], { type: 'text/html' });
    const url = URL.createObjectURL(blob);
    const link = document.createElement('a');
    link.href = url;
    link.download = `${t.invoicePrint.title}-${invoice.invoiceNumber}.html`;
    document.body.appendChild(link);
    link.click();
    document.body.removeChild(link);
    URL.revokeObjectURL(url);
  };

  const renderActions = (invoice: Invoice) => (
    <div className="flex items-center gap-1 justify-end">
        <button
            onClick={() => onEdit(invoice.id)}
            className="p-2 rounded-full text-[--text-secondary] hover:bg-[--bg-tertiary] hover:text-[--text-primary] transition-colors focus:outline-none focus:ring-2 focus:ring-[--primary-500]"
            title={t.invoiceList.actions.edit}
            aria-label={t.invoiceList.actions.edit}
        >
            <PencilIcon className="w-5 h-5" />
        </button>
        <button
            onClick={() => handlePrint(invoice)}
            className="p-2 rounded-full text-[--text-secondary] hover:bg-[--bg-tertiary] hover:text-[--text-primary] transition-colors focus:outline-none focus:ring-2 focus:ring-[--primary-500]"
            title={t.invoiceList.actions.print}
            aria-label={t.invoiceList.actions.print}
        >
            <PrinterIcon className="w-5 h-5" />
        </button>
        <button
            onClick={() => handleDownload(invoice)}
            className="p-2 rounded-full text-[--text-secondary] hover:bg-[--bg-tertiary] hover:text-[--text-primary] transition-colors focus:outline-none focus:ring-2 focus:ring-[--primary-500]"
            title={t.invoiceList.actions.download}
            aria-label={t.invoiceList.actions.download}
        >
            <DownloadIcon className="w-5 h-5" />
        </button>
        <button
            onClick={() => setInvoiceToDelete(invoice.id)}
            className="p-2 rounded-full text-red-400 hover:bg-[--bg-tertiary] hover:text-red-300 transition-colors focus:outline-none focus:ring-2 focus:ring-[--primary-500]"
            title={t.invoiceList.actions.delete}
            aria-label={t.invoiceList.actions.delete}
        >
            <TrashIcon className="w-5 h-5" />
        </button>
    </div>
  );
  
  const renderEmptyState = () => (
    <div className="text-center py-16 px-6">
        <DocumentTextIcon className="mx-auto h-16 w-16 text-[--text-tertiary]/50" />
        <h2 className="mt-6 text-xl font-bold text-[--text-primary]">{t.invoiceList.emptyState.title}</h2>
        <p className="mt-2 text-[--text-tertiary]">{t.invoiceList.emptyState.subtitle}</p>
        <button
          onClick={() => setView('form')}
          className="mt-6 flex items-center gap-2 mx-auto bg-[--primary-600] text-white font-bold py-2 px-5 rounded-lg shadow-lg hover:bg-[--primary-700] focus:outline-none focus:ring-2 focus:ring-[--primary-500] focus:ring-opacity-75 transition-colors"
        >
          <PlusIcon /> {t.invoiceList.newInvoice}
        </button>
    </div>
  );

  return (
    <div className="p-4 md:p-8 w-full">
      <header className="flex flex-col sm:flex-row items-start sm:items-center sm:justify-between mb-8 gap-4">
        <div>
            <h1 className="text-3xl font-bold text-[--text-primary]">{t.invoiceList.title}</h1>
            <p className="text-[--text-tertiary] mt-1">{t.invoiceList.subtitle}</p>
        </div>
        <div className="flex items-center gap-4">
            <button
              onClick={() => setIsComplaintModalOpen(true)}
              className="flex items-center gap-2 bg-[--bg-tertiary] text-[--text-secondary] font-bold py-2 px-5 rounded-lg shadow-lg hover:bg-[--border-primary] focus:outline-none focus:ring-2 focus:ring-[--primary-500] focus:ring-opacity-75 transition-colors"
            >
              <FlagIcon className="w-5 h-5" />
              {t.invoiceList.sendComplaint}
            </button>
            <button
              onClick={() => setView('form')}
              className="flex items-center gap-2 bg-[--primary-600] text-white font-bold py-2 px-5 rounded-lg shadow-lg hover:bg-[--primary-700] focus:outline-none focus:ring-2 focus:ring-[--primary-500] focus:ring-opacity-75 transition-colors"
            >
              <PlusIcon /> {t.invoiceList.newInvoice}
            </button>
        </div>
      </header>
      
      {error && <p className="text-red-400 text-center mt-8 bg-red-900/50 p-3 rounded-md">{error}</p>}

      <div className="bg-[--bg-secondary] rounded-lg shadow-2xl overflow-hidden mt-8">
        {loading ? (
            <p className="text-center p-8 text-[--text-tertiary]">{t.invoiceList.loading}</p>
        ) : !invoices.length ? (
            renderEmptyState()
        ) : (
          <>
            <div className="p-6">
                <h2 className="text-xl font-bold text-[--text-primary]">{t.invoiceList.listTitle}</h2>
                <p className="text-[--text-tertiary] text-sm mt-1">{t.invoiceList.listSubtitle}</p>
            </div>
            
            <div className="px-6 border-b border-[--border-primary] flex items-center gap-2 overflow-x-auto">
                {filterTabs.map(tab => (
                    <button
                        key={tab}
                        onClick={() => setActiveFilter(tab)}
                        className={`px-4 py-2 text-sm font-semibold rounded-t-md transition-colors focus:outline-none whitespace-nowrap ${
                            activeFilter === tab 
                            ? 'text-[--primary-500] border-b-2 border-[--primary-500]' 
                            //? 'bg-[--bg-tertiary] text-[--text-primary]'
                            : 'text-[--text-tertiary] hover:text-[--text-primary]'
                        }`}
                    >
                        {t.invoiceStatus[tab]}
                    </button>
                ))}
            </div>
            
            {filteredInvoices.length > 0 ? (
                <>
                {/* Table for larger screens */}
                <div className="overflow-x-auto hidden md:block">
                  <table className={`w-full ${language === 'ar' ? 'text-right' : 'text-left'}`}>
                    <thead className="border-b border-[--border-primary] bg-opacity-50 text-[--text-tertiary] text-sm">
                      <tr>
                        <th className="p-4 font-medium">{t.invoiceList.table.invoice}</th>
                        <th className="p-4 font-medium">{t.invoiceList.table.client}</th>
                        <th className="p-4 font-medium">{t.invoiceList.table.status}</th>
                        <th className="p-4 font-medium">{t.invoiceList.table.issueDate}</th>
                        <th className="p-4 font-medium">{t.invoiceList.table.dueDate}</th>
                        <th className="p-4 font-medium">{t.invoiceList.table.amount}</th>
                        <th className={`p-4 font-medium ${language === 'ar' ? 'text-left' : 'text-right'}`}>{t.invoiceList.table.actions}</th>
                      </tr>
                    </thead>
                    <tbody>
                      {filteredInvoices.map(invoice => (
                        <tr key={invoice.id} className="border-b border-[--border-primary] last:border-b-0 hover:bg-[--bg-tertiary]/50">
                          <td className="p-4 text-[--text-secondary]">{invoice.invoiceNumber}</td>
                          <td className="p-4 whitespace-nowrap">{invoice.clientName}</td>
                          <td className="p-4">
                            <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getStatusChipClass(invoice.status)}`}>
                              {t.invoiceStatus[invoice.status]}
                            </span>
                          </td>
                          <td className="p-4">{invoice.date}</td>
                          <td className="p-4">{invoice.dueDate}</td>
                          <td className="p-4 font-bold">{formatCurrency(invoice.amount)}</td>
                          <td className={`p-4 ${language === 'ar' ? 'text-left' : 'text-right'}`}>
                             {renderActions(invoice)}
                          </td>
                        </tr>
                      ))}
                    </tbody>
                  </table>
                </div>

                {/* Cards for mobile screens */}
                <div className="block md:hidden p-4 space-y-4">
                  {filteredInvoices.map(invoice => (
                    <div key={invoice.id} className="bg-[--bg-tertiary]/50 rounded-lg p-4 shadow-md">
                        <div className="flex justify-between items-start">
                            <div>
                                <p className="font-bold text-[--text-primary]">{invoice.clientName}</p>
                                <p className="text-sm text-[--text-tertiary]">{invoice.invoiceNumber}</p>
                            </div>
                             <span className={`px-2 py-1 text-xs font-semibold rounded-full whitespace-nowrap ${getStatusChipClass(invoice.status)}`}>
                              {t.invoiceStatus[invoice.status]}
                            </span>
                        </div>
                        <div className="flex justify-between items-end mt-4">
                            <div>
                                <p className="text-lg font-bold text-[--text-primary]">{formatCurrency(invoice.amount)}</p>
                                <p className="text-sm text-[--text-tertiary]">{t.invoiceList.table.dueDate}: {invoice.dueDate}</p>
                            </div>
                            {renderActions(invoice)}
                        </div>
                    </div>
                  ))}
                </div>
                </>
            ) : (
                <div className="text-center py-16 px-6">
                  <p className="text-[--text-tertiary]">{t.invoiceList.noInvoices}</p>
                </div>
            )}
            </>
        )}
      </div>
      
      <ConfirmationModal
        isOpen={!!invoiceToDelete}
        onClose={() => setInvoiceToDelete(null)}
        onConfirm={handleConfirmDelete}
        title={t.invoiceList.deleteModalTitle}
        confirmText={t.invoiceList.actions.delete}
        cancelText={t.invoiceList.actions.cancel}
        confirmVariant="danger"
      >
        <p>{t.invoiceList.confirmDelete}</p>
      </ConfirmationModal>

      <ComplaintModal
        isOpen={isComplaintModalOpen}
        onClose={() => setIsComplaintModalOpen(false)}
      />

    </div>
  );
};

export default InvoiceList;
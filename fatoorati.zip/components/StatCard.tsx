import React from 'react';

interface StatCardProps {
  icon: React.ReactNode;
  title: string;
  value: string | number;
  subtitle: string;
  valueColor?: string;
}

const StatCard: React.FC<StatCardProps> = ({ icon, title, value, subtitle, valueColor = 'text-[--text-primary]' }) => {
  return (
    <div className="bg-[--bg-secondary] p-6 rounded-lg shadow-2xl flex">
      <div className={`text-[--text-tertiary] text-2xl ${value.toString().length > 10 ? 'mt-1' : ''} rtl:ml-5 ltr:mr-5`}>
        {icon}
      </div>
      <div className="flex flex-col">
        <h3 className="text-[--text-tertiary] text-md">{title}</h3>
        <p className={`text-3xl font-bold mt-1 ${valueColor}`}>{value}</p>
        <p className="text-[--text-tertiary]/80 text-sm mt-2">{subtitle}</p>
      </div>
    </div>
  );
};

export default StatCard;
import React, { useState, useEffect } from 'react';
import { addInvoice, getInvoiceById, updateInvoice } from '../services/supabaseService';
import type { View, Invoice } from '../types';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';

interface InvoiceFormProps {
  setView: (view: View) => void;
  invoiceId: string | null;
  setEditingInvoiceId: (id: string | null) => void;
}

const InvoiceForm: React.FC<InvoiceFormProps> = ({ setView, invoiceId, setEditingInvoiceId }) => {
  const { language } = useSettings();
  const t = translations[language].invoiceForm;

  const [formData, setFormData] = useState({
    clientName: '',
    clientEmail: '',
    invoiceNumber: '',
    date: new Date().toISOString().split('T')[0],
    dueDate: '',
    amount: '',
    status: 'pending' as Invoice['status'],
  });
  const [isSaving, setIsSaving] = useState(false);
  const [error, setError] = useState('');
  
  const isEditing = !!invoiceId;

  useEffect(() => {
    if (invoiceId) {
      const loadInvoiceData = async () => {
        try {
          const invoice = await getInvoiceById(invoiceId);
          if (invoice) {
            setFormData({
                clientName: invoice.clientName,
                clientEmail: invoice.clientEmail || '',
                invoiceNumber: invoice.invoiceNumber,
                date: invoice.date,
                dueDate: invoice.dueDate,
                amount: String(invoice.amount),
                status: invoice.status
            });
          } else {
            setError(t.errors.notFound(invoiceId));
          }
        } catch (err) {
            setError(t.errors.load);
            console.error(err);
        }
      };
      loadInvoiceData();
    }
  }, [invoiceId, t]);

  const handleChange = (e: React.ChangeEvent<HTMLInputElement | HTMLSelectElement>) => {
    const { id, value } = e.target;
    setFormData(prev => ({...prev, [id]: value }));
  };


  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!formData.clientName || !formData.clientEmail || !formData.invoiceNumber || !formData.date || !formData.amount || !formData.dueDate) {
      setError(t.errors.allFields);
      return;
    }
    setError('');
    setIsSaving(true);
    
    const invoiceData = {
        clientName: formData.clientName,
        clientEmail: formData.clientEmail,
        invoiceNumber: formData.invoiceNumber,
        date: formData.date,
        dueDate: formData.dueDate,
        amount: parseFloat(formData.amount),
        status: formData.status
    };

    try {
      if (isEditing && invoiceId) {
        await updateInvoice(invoiceId, invoiceData);
        alert(t.alerts.updateSuccess);
      } else {
        await addInvoice(invoiceData);
        alert(t.alerts.createSuccess);
      }
      setEditingInvoiceId(null);
      setView('invoices');
    } catch (err) {
      setError(isEditing ? t.errors.update : t.errors.create);
      console.error(err);
    } finally {
      setIsSaving(false);
    }
  };
  
  const handleBack = () => {
    setEditingInvoiceId(null);
    setView('invoices');
  }

  const inputClasses = "w-full p-3 bg-[--bg-tertiary] text-[--text-primary] border border-[--border-primary] rounded-md focus:ring-2 focus:ring-[--primary-500] focus:border-[--primary-500] outline-none transition";

  return (
    <div className="p-4 md:p-8 max-w-4xl mx-auto">
      <header className="flex items-center justify-between mb-8">
        <h1 className="text-3xl font-bold text-[--text-primary]">{isEditing ? t.editTitle : t.newTitle}</h1>
        <button
          onClick={handleBack}
          className="text-[--text-tertiary] hover:text-[--text-primary] transition-colors"
        >
          {language === 'ar' ? '→' : '←'} {t.back}
        </button>
      </header>
      <form onSubmit={handleSubmit} className="space-y-6 bg-[--bg-secondary] p-8 rounded-lg shadow-2xl">
        {error && <p className="text-red-400 text-center bg-red-900/50 p-3 rounded-md">{error}</p>}
        <div>
          <label htmlFor="clientName" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.clientName}</label>
          <input id="clientName" type="text" value={formData.clientName} onChange={handleChange} className={inputClasses} required />
        </div>
        <div>
          <label htmlFor="clientEmail" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.clientEmail}</label>
          <input id="clientEmail" type="email" value={formData.clientEmail} onChange={handleChange} className={inputClasses} required />
        </div>
        <div>
          <label htmlFor="invoiceNumber" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.invoiceNumber}</label>
          <input id="invoiceNumber" type="text" value={formData.invoiceNumber} onChange={handleChange} className={inputClasses} required />
        </div>
        <div>
          <label htmlFor="date" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.issueDate}</label>
          <input id="date" type="date" value={formData.date} onChange={handleChange} className={inputClasses} required />
        </div>
        <div>
          <label htmlFor="dueDate" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.dueDate}</label>
          <input id="dueDate" type="date" value={formData.dueDate} onChange={handleChange} className={inputClasses} required />
        </div>
        <div>
          <label htmlFor="amount" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.amount}</label>
          <input id="amount" type="number" step="0.01" value={formData.amount} onChange={handleChange} className={inputClasses} required />
        </div>
        {isEditing && (
             <div>
                <label htmlFor="status" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.status}</label>
                <select id="status" value={formData.status} onChange={handleChange} className={inputClasses}>
                    <option value="draft">{translations[language].invoiceStatus.draft}</option>
                    <option value="pending">{translations[language].invoiceStatus.pending}</option>
                    <option value="paid">{translations[language].invoiceStatus.paid}</option>
                    <option value="overdue">{translations[language].invoiceStatus.overdue}</option>
                </select>
             </div>
        )}
        <button
          type="submit"
          disabled={isSaving}
          className="w-full bg-[--primary-600] text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:bg-[--primary-700] focus:outline-none focus:ring-2 focus:ring-[--primary-500] focus:ring-opacity-75 transition-colors disabled:bg-[--primary-400] disabled:cursor-not-allowed"
        >
          {isSaving ? t.saving : (isEditing ? t.saveChanges : t.saveInvoice)}
        </button>
      </form>
    </div>
  );
};

export default InvoiceForm;
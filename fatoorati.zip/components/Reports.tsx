import React, { useState, useEffect, useCallback, useMemo, useRef } from 'react';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';
import { getRevenueReportData } from '../services/supabaseService';
import type { ReportPeriod, RevenueReport, RevenueDataPoint } from '../types';
import StatCard from './StatCard';
import { DollarIcon, DocumentTextIcon, ChartBarIcon } from './Icons';


const Reports: React.FC = () => {
  const { language, formatCurrency, primaryColor } = useSettings();
  const t = translations[language].reports;

  const [report, setReport] = useState<RevenueReport | null>(null);
  const [loading, setLoading] = useState(true);
  const [period, setPeriod] = useState<ReportPeriod>('last30');
  const [hoveredPoint, setHoveredPoint] = useState<(RevenueDataPoint & { x: number; y: number }) | null>(null);
  const [tooltipPosition, setTooltipPosition] = useState<{ x: number; y: number } | null>(null);
  const svgRef = useRef<SVGSVGElement>(null);


  const selectClasses = "w-full sm:w-auto bg-[--bg-tertiary] text-[--text-primary] border border-[--border-primary] rounded-md py-2 px-3 focus:ring-2 focus:ring-[--primary-500] focus:border-[--primary-500] outline-none transition";
  
  const fetchReportData = useCallback(async (currentPeriod: ReportPeriod) => {
    setLoading(true);
    setHoveredPoint(null); // Reset hover state on new data fetch
    try {
        const data = await getRevenueReportData(currentPeriod, language);
        setReport(data);
    } catch (error) {
        console.error("Failed to fetch report data", error);
        setReport(null); // Or set an error state
    } finally {
        setLoading(false);
    }
  }, [language]);

  useEffect(() => {
    fetchReportData(period);
  }, [period, fetchReportData]);

  // Chart constants and calculations
  const chartPadding = { top: 20, right: 30, bottom: 40, left: 70 };
  const chartWidth = 800;
  const chartHeight = 400;
  
  const maxChartValue = useMemo(() => {
    if (!report?.data || report.data.length === 0) return 1000; // Default max value
    const maxValue = Math.max(...report.data.map(d => d.value));
    return Math.ceil(maxValue / 500) * 500 * 1.1; // Round up and add padding
  }, [report]);

  const yAxisTicks = useMemo(() => {
    const ticks = 5;
    return Array.from({ length: ticks + 1 }, (_, i) => {
      const value = (maxChartValue / ticks) * i;
      const y = chartHeight - chartPadding.bottom - (value / maxChartValue) * (chartHeight - chartPadding.top - chartPadding.bottom);
      return { value, y };
    });
  }, [maxChartValue, chartHeight, chartPadding]);

  const points = useMemo(() => {
    if (!report?.data || report.data.length === 0) return [];
    const data = report.data;
    const availableWidth = chartWidth - chartPadding.left - chartPadding.right;
    const availableHeight = chartHeight - chartPadding.top - chartPadding.bottom;

    // Handle case with a single data point
    if (data.length === 1) {
        const x = chartPadding.left + availableWidth / 2;
        const y = chartHeight - chartPadding.bottom - (data[0].value / maxChartValue) * availableHeight;
        return [{...data[0], x, y}];
    }

    return data.map((point, index) => {
      const x = chartPadding.left + (index / (data.length - 1)) * availableWidth;
      const y = chartHeight - chartPadding.bottom - (point.value / maxChartValue) * availableHeight;
      return { ...point, x, y };
    });
  }, [report, maxChartValue, chartWidth, chartHeight, chartPadding]);
  
  const [smoothedLinePath, areaPath] = useMemo(() => {
    if (points.length < 1) return ['', ''];
    if (points.length === 1) {
        const p = points[0];
        const line = `M ${p.x - 10},${p.y} L ${p.x + 10},${p.y}`;
        const area = `M ${p.x - 10},${p.y} L ${p.x + 10},${p.y} L ${p.x + 10},${chartHeight-chartPadding.bottom} L ${p.x-10},${chartHeight-chartPadding.bottom} Z`;
        return [line, area];
    }
    
    const linePath = points.reduce((acc, point, i, a) => {
      if (i === 0) return `M ${point.x},${point.y}`;
      const [prevPoint] = [a[i - 1]];
      const cp1x = prevPoint.x + (point.x - prevPoint.x) / 3;
      const cp1y = prevPoint.y;
      const cp2x = point.x - (point.x - prevPoint.x) / 3;
      const cp2y = point.y;
      return `${acc} C ${cp1x},${cp1y} ${cp2x},${cp2y} ${point.x},${point.y}`;
    }, '');
    
    const firstPoint = points[0];
    const lastPoint = points[points.length - 1];
    const finalAreaPath = `${linePath} L ${lastPoint.x},${chartHeight - chartPadding.bottom} L ${firstPoint.x},${chartHeight - chartPadding.bottom} Z`;

    return [linePath, finalAreaPath];
  }, [points, chartHeight, chartPadding]);


  const handleMouseMove = (e: React.MouseEvent<SVGSVGElement>) => {
    if (!points || points.length === 0 || !svgRef.current) return;

    const svg = svgRef.current;
    const pt = svg.createSVGPoint();
    pt.x = e.clientX;
    pt.y = e.clientY;

    const cursorPoint = pt.matrixTransform(svg.getScreenCTM()?.inverse());
    
    const closestPoint = points.reduce((prev, curr) => 
        Math.abs(curr.x - cursorPoint.x) < Math.abs(prev.x - cursorPoint.x) ? curr : prev
    );

    setHoveredPoint(closestPoint);
    setTooltipPosition({ x: closestPoint.x, y: closestPoint.y });
  };


  const accentColors: Record<string, string> = {
    blue: '#3b82f6', green: '#22c55e', purple: '#8b5cf6',
    orange: '#f97316', red: '#ef4444', teal: '#14b8a6'
  };
  const currentAccentColor = accentColors[primaryColor] || '#3b82f6';
  const gradientId = `chartGradient-${primaryColor}`;

  return (
    <div className="p-4 md:p-8 w-full">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-[--text-primary]">{t.title}</h1>
        <p className="text-[--text-tertiary] mt-2">{t.subtitle}</p>
      </header>
      
      <div className="flex flex-col sm:flex-row justify-between sm:items-center mb-6 gap-4">
          <div className="flex items-center">
            <label htmlFor="period" className="text-sm font-medium text-[--text-secondary] rtl:ml-3 ltr:mr-3 whitespace-nowrap">{t.period.label}</label>
            <select
              id="period"
              name="period"
              className={selectClasses}
              value={period}
              onChange={(e) => setPeriod(e.target.value as ReportPeriod)}
            >
              <option value="last7">{t.period.last7}</option>
              <option value="last30">{t.period.last30}</option>
              <option value="thisYear">{t.period.thisYear}</option>
            </select>
          </div>
        </div>

      {loading ? (
        <div className="flex items-center justify-center text-center py-16 text-[--text-tertiary]">{t.loading}</div>
      ) : report ? (
        <div>
            {/* Stat Cards at the top */}
            <div className="grid grid-cols-1 md:grid-cols-3 gap-6 mb-8">
                 <StatCard 
                    icon={<DollarIcon />} 
                    title={t.totalRevenue} 
                    value={formatCurrency(report.totalRevenue)}
                    subtitle={""} 
                 />
                 <StatCard 
                    icon={<ChartBarIcon />} 
                    title={t.avgInvoiceValue} 
                    value={formatCurrency(Math.round(report.avgInvoiceValue))}
                    subtitle={""} 
                 />
                 <StatCard 
                    icon={<DocumentTextIcon />} 
                    title={t.totalInvoices} 
                    value={report.totalInvoices}
                    subtitle={""} 
                 />
            </div>
            
            {/* Chart in its own container below */}
            <div className="bg-[--bg-secondary] rounded-lg shadow-2xl p-4 sm:p-6">
                <h2 className="text-xl font-bold text-[--text-primary]">{t.analysis.title}</h2>
                <div 
                    className="relative mt-6 w-full h-[400px]"
                    onMouseLeave={() => setHoveredPoint(null)}
                >
                  <svg ref={svgRef} className="w-full h-full" viewBox={`0 0 ${chartWidth} ${chartHeight}`} preserveAspectRatio="xMidYMid meet" onMouseMove={handleMouseMove}>
                    <defs>
                        <linearGradient id={gradientId} x1="0" y1="0" x2="0" y2="1">
                            <stop offset="0%" stopColor={currentAccentColor} stopOpacity={0.4} />
                            <stop offset="100%" stopColor={currentAccentColor} stopOpacity={0} />
                        </linearGradient>
                    </defs>

                    {/* Y-Axis Labels and Grid Lines */}
                    {yAxisTicks.map(tick => (
                        <g key={tick.value} className="text-xs text-[--text-tertiary]">
                            <text x={chartPadding.left - 10} y={tick.y} dominantBaseline="middle" textAnchor="end" fill="currentColor" className="text-[10px] sm:text-xs">
                                {formatCurrency(tick.value, {maximumFractionDigits: 0})}
                            </text>
                            <line
                                x1={chartPadding.left} y1={tick.y}
                                x2={chartWidth - chartPadding.right} y2={tick.y}
                                className="stroke-current opacity-20"
                                strokeDasharray="2,3"
                            />
                        </g>
                    ))}
                    {/* X-Axis Labels */}
                    {points.map((point, index) => {
                        const showLabel = points.length < 15 || index % Math.floor(points.length / 8) === 0;
                        return (
                           showLabel &&
                           <text key={index} x={point.x} y={chartHeight - chartPadding.bottom + 20} textAnchor="middle" className="text-[10px] sm:text-xs text-[--text-tertiary]" fill="currentColor">{point.label}</text>
                        )
                    })}

                    {/* Area Path */}
                    <path d={areaPath} fill={`url(#${gradientId})`} className="chart-area" />
                    
                    {/* Line Chart Path */}
                    <path d={smoothedLinePath} fill="none" stroke={currentAccentColor} strokeWidth="2.5" strokeLinecap="round" strokeLinejoin="round" className="chart-line" />
                    
                    {/* Hover Indicator */}
                    {hoveredPoint && tooltipPosition && (
                       <g className="pointer-events-none">
                         <line
                            x1={tooltipPosition.x} y1={chartPadding.top}
                            x2={tooltipPosition.x} y2={chartHeight - chartPadding.bottom}
                            className="stroke-current text-[--text-tertiary]"
                            strokeWidth="1"
                            strokeDasharray="3,3"
                         />
                         <circle cx={tooltipPosition.x} cy={tooltipPosition.y} r="5" fill="var(--bg-secondary)" stroke={currentAccentColor} strokeWidth="2" />
                       </g>
                    )}
                  </svg>
                   {hoveredPoint && tooltipPosition && (
                        <div 
                            className="absolute p-2 rounded-lg bg-[--bg-tertiary]/80 backdrop-blur-sm text-xs text-[--text-primary] shadow-lg pointer-events-none transition-transform duration-100"
                            style={{ 
                                top: 0, 
                                left: 0,
                                transform: `translate(calc(${tooltipPosition.x}px - 50%), calc(${tooltipPosition.y}px - 120%))`
                            }}>
                            <div className="font-bold whitespace-nowrap">{hoveredPoint.label}</div>
                            <div className="whitespace-nowrap">{formatCurrency(hoveredPoint.value)}</div>
                        </div>
                    )}
                </div>
            </div>
        </div>
      ) : (
        <div className="flex items-center justify-center text-center py-16 text-[--text-tertiary]">Error loading data.</div>
      )}
      <style>{`
        .chart-line {
            stroke-dasharray: 2000;
            stroke-dashoffset: 2000;
            animation: draw-line 2s cubic-bezier(0.25, 1, 0.5, 1) forwards;
        }
        .chart-area {
            opacity: 0;
            animation: fade-in-area 1s 0.5s ease-out forwards;
        }
        @keyframes draw-line {
            to { stroke-dashoffset: 0; }
        }
        @keyframes fade-in-area {
            to { opacity: 1; }
        }
      `}</style>
    </div>
  );
};

export default Reports;
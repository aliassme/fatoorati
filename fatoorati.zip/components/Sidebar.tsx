import React from 'react';
import type { View } from '../types';
import { HomeIcon, DocumentTextIcon, ChartBarIcon, CogIcon, EnvelopeIcon } from './Icons';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';

interface SidebarProps {
  currentView: View;
  setView: (view: View) => void;
}

const NavLink: React.FC<{
  viewName: View;
  currentView: View;
  setView: (view: View) => void;
  icon: React.ReactNode;
  label: string;
  language: 'ar' | 'en';
}> = ({ viewName, currentView, setView, icon, label, language }) => {
  const isActive = currentView === viewName;
  const baseClasses = "flex items-center w-full p-3 rounded-lg transition-colors";
  const activeClasses = "bg-[--bg-tertiary] text-[--text-primary] font-bold";
  const inactiveClasses = "text-[--text-tertiary] hover:bg-[--bg-tertiary]/50 hover:text-[--text-primary]";
  const marginClass = language === 'ar' ? 'mr-3' : 'ml-3';
  const iconMarginClass = language === 'ar' ? 'ml-4' : 'mr-4';

  return (
    <li>
      <button
        onClick={() => setView(viewName)}
        className={`${baseClasses} ${isActive ? activeClasses : inactiveClasses}`}
      >
        <span className={iconMarginClass}>{icon}</span>
        <span>{label}</span>
      </button>
    </li>
  );
};

const Sidebar: React.FC<SidebarProps> = ({ currentView, setView }) => {
  const { language } = useSettings();
  const t = translations[language].sidebar;
  const marginClass = language === 'ar' ? 'mr-3' : 'ml-3';

  return (
    <aside className="w-64 bg-[--bg-secondary] px-6 flex-col h-screen shadow-2xl hidden md:flex pt-[calc(1.5rem+env(safe-area-inset-top))] pb-[calc(1.5rem+env(safe-area-inset-bottom))]">
      <div className="flex items-center mb-12">
        <EnvelopeIcon className="text-[--primary-500] w-8 h-8" />
        <h1 className={`text-2xl font-bold text-[--text-primary] ${marginClass}`}>{t.title}</h1>
      </div>
      <nav className="flex-grow">
        <ul className="space-y-3">
          <NavLink viewName="dashboard" currentView={currentView} setView={setView} icon={<HomeIcon />} label={t.dashboard} language={language}/>
          <NavLink viewName="invoices" currentView={currentView} setView={setView} icon={<DocumentTextIcon />} label={t.invoices} language={language}/>
          <NavLink viewName="reports" currentView={currentView} setView={setView} icon={<ChartBarIcon />} label={t.reports} language={language}/>
          <NavLink viewName="settings" currentView={currentView} setView={setView} icon={<CogIcon />} label={t.settings} language={language}/>
        </ul>
      </nav>
    </aside>
  );
};

export default Sidebar;
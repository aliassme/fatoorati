import React, { useState, useEffect } from 'react';
import { CogIcon, CloudArrowUpIcon, CloudArrowDownIcon } from './Icons';
import { 
    scheduleAccountDeletion, 
    cancelAccountDeletion, 
    getAccountDeletionStatus,
    backupInvoicesToCloud,
    restoreInvoicesFromCloud,
    getLastBackupTimestamp
} from '../services/supabaseService';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';
import { Currency, currencies, Language, PrimaryColor, Theme } from '../types';

interface ToggleSwitchProps {
  checked: boolean;
  onChange: (checked: boolean) => void;
}

const ToggleSwitch: React.FC<ToggleSwitchProps> = ({ checked, onChange }) => {
  const bgClass = checked ? 'bg-[--primary-500]' : 'bg-[--bg-tertiary]';
  const circleClass = checked ? 'translate-x-5' : 'translate-x-0';
  const rtlCircleClass = checked ? '-translate-x-5' : '-translate-x-0';
  const { language } = useSettings();

  return (
    <button
      type="button"
      role="switch"
      aria-checked={checked}
      onClick={() => onChange(!checked)}
      className={`relative inline-flex h-6 w-11 flex-shrink-0 cursor-pointer rounded-full border-2 border-transparent transition-colors duration-200 ease-in-out focus:outline-none focus:ring-2 focus:ring-[--primary-500] focus:ring-offset-2 focus:ring-offset-[--bg-primary] ${bgClass}`}
    >
      <span
        aria-hidden="true"
        className={`pointer-events-none inline-block h-5 w-5 transform rounded-full bg-white shadow ring-0 transition duration-200 ease-in-out ${language === 'ar' ? rtlCircleClass : circleClass}`}
      />
    </button>
  );
};

const Settings: React.FC = () => {
  const { language, setLanguage, currency, setCurrency, theme, setTheme, primaryColor, setPrimaryColor } = useSettings();
  const t = translations[language].settings;

  const [invoiceUpdates, setInvoiceUpdates] = useState(true);
  const [weeklySummary, setWeeklySummary] = useState(false);
  const [promotions, setPromotions] = useState(false);
  const [deletionScheduledAt, setDeletionScheduledAt] = useState<string | null>(null);
  const [isLoadingStatus, setIsLoadingStatus] = useState(true);
  const [isSyncing, setIsSyncing] = useState(false);
  const [lastBackupDate, setLastBackupDate] = useState<string | null>(null);


  useEffect(() => {
    const checkStatus = async () => {
      setIsLoadingStatus(true);
      const [status, lastBackup] = await Promise.all([
        getAccountDeletionStatus(),
        getLastBackupTimestamp()
      ]);
      setDeletionScheduledAt(status);
      setLastBackupDate(lastBackup);
      setIsLoadingStatus(false);
    };
    checkStatus();
  }, []);

  const handleDeleteAccount = async () => {
    if (window.confirm(t.deleteAccount.confirm)) {
      try {
        const timestamp = await scheduleAccountDeletion();
        setDeletionScheduledAt(timestamp);
        alert(t.deleteAccount.alerts.scheduled);
      } catch (error) {
        alert(t.deleteAccount.alerts.error);
        console.error(error);
      }
    }
  };

  const handleCancelDeletion = async () => {
    try {
      await cancelAccountDeletion();
      setDeletionScheduledAt(null);
      alert(t.deleteAccount.alerts.cancelled);
    } catch (error) {
      alert(t.deleteAccount.alerts.cancelError);
      console.error(error);
    }
  };
  
  const handleCloudBackup = async () => {
    setIsSyncing(true);
    try {
        const timestamp = await backupInvoicesToCloud();
        setLastBackupDate(timestamp);
        alert(t.cloudBackup.backup.success);
    } catch (error) {
        console.error('Cloud backup failed:', error);
        alert(t.cloudBackup.backup.error);
    } finally {
        setIsSyncing(false);
    }
  };

  const handleCloudRestore = async () => {
    if (!window.confirm(t.cloudBackup.restore.confirm)) {
        return;
    }
    setIsSyncing(true);
    try {
        await restoreInvoicesFromCloud();
        alert(t.cloudBackup.restore.success);
        // You might want to force a reload to refresh all data across the app
        window.location.reload();
    } catch (error) {
        console.error('Cloud restore failed:', error);
        alert(t.cloudBackup.restore.error);
    } finally {
        setIsSyncing(false);
    }
  };

  const formatTimestamp = (timestamp: string | null) => {
    if (!timestamp) return t.cloudBackup.lastBackup.never;
    return new Date(timestamp).toLocaleString(language, {
        dateStyle: 'long',
        timeStyle: 'short'
    });
  };

  const formattedDeletionDate = deletionScheduledAt 
    ? new Date(deletionScheduledAt).toLocaleString(language, {
        year: 'numeric', month: 'long', day: 'numeric', hour: '2-digit', minute: '2-digit'
      })
    : '';
  
  const settingCardClasses = "bg-[--bg-secondary] rounded-lg shadow-2xl p-6";
  const selectClasses = "w-full sm:w-auto bg-[--bg-tertiary] text-[--text-primary] border border-[--border-primary] rounded-md py-2 px-3 focus:ring-2 focus:ring-[--primary-500] focus:border-[--primary-500] outline-none transition";

  const colorSwatches: { name: PrimaryColor, bg: string }[] = [
      { name: 'blue', bg: 'bg-blue-500' },
      { name: 'green', bg: 'bg-green-500' },
      { name: 'purple', bg: 'bg-purple-500' },
      { name: 'orange', bg: 'bg-orange-500' },
      { name: 'red', bg: 'bg-red-500' },
      { name: 'teal', bg: 'bg-teal-500' },
  ];

  return (
    <div className="p-4 md:p-8 w-full max-w-5xl mx-auto">
      <header className="mb-8">
        <h1 className="text-3xl font-bold text-[--text-primary]">{t.title}</h1>
        <p className="text-[--text-tertiary] mt-2">{t.subtitle}</p>
      </header>

      <div className="space-y-8">
        {/* Appearance Card */}
        <div className={settingCardClasses}>
            <h3 className="text-xl font-bold text-[--text-primary] mb-2">{t.appearance.title}</h3>
            <p className="text-[--text-tertiary] mt-1 mb-4">{t.appearance.subtitle}</p>
            <ul className="divide-y divide-[--border-primary] -mx-6">
                <li className="p-6">
                    <h3 className="font-bold text-[--text-primary] mb-1">{t.appearance.theme.label}</h3>
                    <p className="text-[--text-tertiary] text-sm mb-4">{t.appearance.theme[theme]}</p>
                    <div className="flex items-center gap-2 p-1 rounded-lg bg-[--bg-tertiary]">
                        {(['light', 'dark', 'slate', 'ocean'] as Theme[]).map((themeOption) => (
                            <button
                                key={themeOption}
                                onClick={() => setTheme(themeOption)}
                                className={`flex-1 py-2 px-3 text-sm font-bold rounded-md transition-colors focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[--bg-tertiary] focus:ring-[--primary-500] ${
                                    theme === themeOption
                                        ? 'bg-[--bg-secondary] text-[--text-primary] shadow-sm'
                                        : 'text-[--text-tertiary] hover:bg-[--bg-secondary]/50'
                                }`}
                            >
                                {t.appearance.theme[themeOption]}
                            </button>
                        ))}
                    </div>
                </li>
                 <li className="p-6">
                    <h3 className="font-bold text-[--text-primary] mb-2">{t.appearance.primaryColor}</h3>
                     <div className="flex items-center gap-4">
                        {colorSwatches.map(color => (
                            <button
                                key={color.name}
                                aria-label={`Set color to ${color.name}`}
                                onClick={() => setPrimaryColor(color.name)}
                                className={`w-8 h-8 rounded-full ${color.bg} transition-transform hover:scale-110 ${primaryColor === color.name ? 'ring-2 ring-offset-2 ring-offset-[--bg-secondary] ring-white' : ''}`}
                            />
                        ))}
                    </div>
                </li>
            </ul>
        </div>

        {/* Language & Region Card */}
        <div className={settingCardClasses}>
            <h3 className="text-xl font-bold text-[--text-primary] mb-2">{t.languageRegion.title}</h3>
            <p className="text-[--text-tertiary] mt-1 mb-4">{t.languageRegion.subtitle}</p>
            <ul className="divide-y divide-[--border-primary] -mx-6">
                <li className="p-6 flex justify-between items-center">
                    <h3 className="font-bold text-[--text-primary]">{t.languageRegion.language}</h3>
                    <select value={language} onChange={(e) => setLanguage(e.target.value as Language)} className={selectClasses}>
                        <option value="ar">العربية</option>
                        <option value="en">English</option>
                    </select>
                </li>
                <li className="p-6 flex justify-between items-center">
                    <h3 className="font-bold text-[--text-primary]">{t.languageRegion.currency}</h3>
                     <select value={currency} onChange={(e) => setCurrency(e.target.value as Currency)} className={selectClasses}>
                        {Object.keys(currencies).map(key => (
                           <option key={key} value={key}>{key} ({currencies[key as Currency].symbol})</option>
                        ))}
                    </select>
                </li>
            </ul>
        </div>

        {/* Notifications Card */}
        <div className={settingCardClasses}>
            <h3 className="text-xl font-bold text-[--text-primary] mb-2">{t.notifications.title}</h3>
            <p className="text-[--text-tertiary] mt-1 mb-4">{t.notifications.subtitle}</p>
            <ul className="divide-y divide-[--border-primary] -mx-6">
                <li className="p-6 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-[--text-primary]">{t.notifications.invoiceUpdates.title}</h3>
                    <p className="text-[--text-tertiary] text-sm mt-1">{t.notifications.invoiceUpdates.subtitle}</p>
                </div>
                <ToggleSwitch checked={invoiceUpdates} onChange={setInvoiceUpdates} />
                </li>
                <li className="p-6 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-[--text-primary]">{t.notifications.weeklySummary.title}</h3>
                    <p className="text-[--text-tertiary] text-sm mt-1">{t.notifications.weeklySummary.subtitle}</p>
                </div>
                <ToggleSwitch checked={weeklySummary} onChange={setWeeklySummary} />
                </li>
                <li className="p-6 flex justify-between items-center">
                <div>
                    <h3 className="font-bold text-[--text-primary]">{t.notifications.promotions.title}</h3>
                    <p className="text-[--text-tertiary] text-sm mt-1">{t.notifications.promotions.subtitle}</p>
                </div>
                <ToggleSwitch checked={promotions} onChange={setPromotions} />
                </li>
            </ul>
        </div>
        
        {/* Cloud Backup Card */}
        <div className={settingCardClasses}>
            <h3 className="text-xl font-bold text-[--text-primary] mb-2">{t.cloudBackup.title}</h3>
            <p className="text-[--text-tertiary] mt-1 mb-4">{t.cloudBackup.subtitle}</p>
            <ul className="divide-y divide-[--border-primary] -mx-6">
                <li className="p-6">
                    <div className="flex flex-col sm:flex-row justify-between sm:items-center gap-4">
                        <div>
                            <h3 className="font-bold text-[--text-primary]">{t.cloudBackup.backup.title}</h3>
                            <p className="text-[--text-tertiary] text-sm mt-1">{t.cloudBackup.backup.subtitle}</p>
                            <p className="text-xs text-[--text-tertiary]/70 mt-2">{t.cloudBackup.lastBackup.title} {formatTimestamp(lastBackupDate)}</p>
                        </div>
                        <button 
                            onClick={handleCloudBackup}
                            disabled={isSyncing}
                            className="flex items-center gap-2 px-4 py-2 bg-[--primary-600]/90 text-white font-bold rounded-md hover:bg-[--primary-600] transition-colors self-start sm:self-center disabled:bg-[--primary-400] disabled:cursor-wait"
                        >
                            <CloudArrowUpIcon className="w-5 h-5" />
                            {isSyncing ? t.cloudBackup.syncing : t.cloudBackup.backup.button}
                        </button>
                    </div>
                </li>
                <li className="p-6">
                     <div>
                        <h3 className="font-bold text-[--text-primary]">{t.cloudBackup.restore.title}</h3>
                        <p className="text-[--text-tertiary] text-sm mt-1 mb-4">{t.cloudBackup.restore.subtitle}</p>
                    </div>
                    <button
                        onClick={handleCloudRestore}
                        disabled={isSyncing}
                        className="flex items-center gap-2 px-4 py-2 bg-slate-600 text-white font-bold rounded-md hover:bg-slate-500 transition-colors disabled:bg-slate-400 disabled:cursor-wait"
                    >
                         <CloudArrowDownIcon className="w-5 h-5" />
                        {isSyncing ? t.cloudBackup.syncing : t.cloudBackup.restore.button}
                    </button>
                </li>
            </ul>
        </div>


        {/* Support Card */}
        <div className={settingCardClasses}>
          <h3 className="text-xl font-bold text-[--text-primary]">{t.support.title}</h3>
          <p className="text-[--text-tertiary] mt-2 mb-4">{t.support.subtitle}</p>
          <button className="flex items-center justify-center px-4 py-2 border border-[--border-primary] text-[--text-secondary] rounded-md hover:bg-[--bg-tertiary] hover:text-[--text-primary] transition-colors">
            <CogIcon className="w-5 h-5 rtl:ml-2 ltr:mr-2" />
            {t.support.button}
          </button>
        </div>

        {/* Delete Account Card */}
        <div className={`${settingCardClasses} border border-red-500/30`}>
            <h3 className="text-xl font-bold text-red-400">{t.deleteAccount.title}</h3>
            {isLoadingStatus ? (
            <p className="text-[--text-tertiary] mt-2">{t.deleteAccount.loading}</p>
            ) : deletionScheduledAt ? (
            <div>
                <p className="text-[--text-tertiary] mt-2 mb-4" dangerouslySetInnerHTML={{ __html: t.deleteAccount.scheduledInfo(formattedDeletionDate)}} />
                <button 
                onClick={handleCancelDeletion}
                className="px-5 py-2 bg-slate-600 text-white font-bold rounded-md hover:bg-slate-500 transition-colors"
                >
                {t.deleteAccount.cancelButton}
                </button>
            </div>
            ) : (
            <div>
                <p className="text-[--text-tertiary] mt-2 mb-4">{t.deleteAccount.description}</p>
                <button 
                onClick={handleDeleteAccount}
                className="px-5 py-2 bg-red-800 text-white font-bold rounded-md hover:bg-red-700 transition-colors"
                >
                {t.deleteAccount.requestButton}
                </button>
            </div>
            )}
        </div>

        {/* Logout Card */}
        <div className={settingCardClasses}>
          <h3 className="text-xl font-bold text-[--text-primary]">{t.logout.title}</h3>
          <p className="text-[--text-tertiary] mt-2 mb-4">{t.logout.subtitle}</p>
          <button className="px-5 py-2 bg-red-800/80 text-white font-bold rounded-md hover:bg-red-700/80 transition-colors">
            {t.logout.button}
          </button>
        </div>
      </div>
    </div>
  );
};

export default Settings;
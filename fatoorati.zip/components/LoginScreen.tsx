import React, { useState } from 'react';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';
import { EnvelopeIcon, PhoneIcon } from './Icons';
import { countryData } from '../types';

interface LoginScreenProps {
  onLoginSuccess: () => void;
}

const LoginScreen: React.FC<LoginScreenProps> = ({ onLoginSuccess }) => {
    const { language } = useSettings();
    const t = translations[language];

    const [authMode, setAuthMode] = useState<'login' | 'signup'>('login');
    const [loginMethod, setLoginMethod] = useState<'email' | 'phone'>('email');
    const [email, setEmail] = useState('');
    const [phone, setPhone] = useState('');
    const [password, setPassword] = useState('');
    const [selectedCountryCode, setSelectedCountryCode] = useState(countryData[0].code);

    const handleSubmit = (e: React.FormEvent) => {
        e.preventDefault();
        // Here you would typically handle the real authentication logic.
        // For this demo, we'll just simulate a successful login.
        onLoginSuccess();
    };

    const baseInputClasses = "w-full p-3 bg-[--bg-tertiary] text-[--text-primary] border border-[--border-primary] rounded-md focus:ring-2 focus:ring-[--primary-500] focus:border-[--primary-500] outline-none transition";
    const selectClasses = `bg-[--bg-tertiary] text-[--text-primary] border border-[--border-primary] rounded-md focus:ring-2 focus:ring-[--primary-500] focus:border-[--primary-500] outline-none transition p-3`;


    return (
        <div className="min-h-screen flex items-center justify-center bg-[--bg-primary] p-4 font-sans login-bg">
            <div className="w-full max-w-md">
                <div className="text-center mb-8">
                    <EnvelopeIcon className="mx-auto h-12 w-12 text-[--primary-500]" />
                    <h1 className="text-3xl font-bold text-[--text-primary] mt-4">{t.loginScreen.welcome}</h1>
                    <p className="text-[--text-tertiary] mt-2">{t.loginScreen.subtitle}</p>
                </div>

                <div className="bg-[--bg-secondary] p-2 rounded-lg flex items-center mb-6">
                    <button
                        onClick={() => setAuthMode('login')}
                        className={`w-1/2 py-2.5 text-sm font-bold rounded-md transition-all duration-300 ${authMode === 'login' ? 'bg-[--bg-primary] text-[--text-primary] shadow-md' : 'text-[--text-tertiary] hover:text-[--text-primary]'}`}
                    >
                        {t.loginScreen.login}
                    </button>
                    <button
                        onClick={() => setAuthMode('signup')}
                        className={`w-1/2 py-2.5 text-sm font-bold rounded-md transition-all duration-300 ${authMode === 'signup' ? 'bg-[--bg-primary] text-[--text-primary] shadow-md' : 'text-[--text-tertiary] hover:text-[--text-primary]'}`}
                    >
                        {t.loginScreen.signup}
                    </button>
                </div>

                <div className="flex justify-center items-center gap-4 mb-6">
                     <button
                        onClick={() => setLoginMethod('email')}
                        className={`flex items-center gap-2 py-2 px-4 border rounded-lg transition-colors text-sm font-semibold ${loginMethod === 'email' ? 'border-[--primary-500] text-[--primary-500] bg-[--primary-500]/10' : 'border-[--border-primary] text-[--text-tertiary] hover:border-[--primary-500]/50 hover:text-[--text-primary]'}`}
                    >
                        <EnvelopeIcon className="w-5 h-5"/>
                        {t.loginScreen.email}
                    </button>
                     <button
                        onClick={() => setLoginMethod('phone')}
                        className={`flex items-center gap-2 py-2 px-4 border rounded-lg transition-colors text-sm font-semibold ${loginMethod === 'phone' ? 'border-[--primary-500] text-[--primary-500] bg-[--primary-500]/10' : 'border-[--border-primary] text-[--text-tertiary] hover:border-[--primary-500]/50 hover:text-[--text-primary]'}`}
                    >
                        <PhoneIcon className="w-5 h-5"/>
                        {t.loginScreen.phone}
                    </button>
                </div>

                <form onSubmit={handleSubmit} className="space-y-6">
                    {loginMethod === 'email' ? (
                        <div>
                            <label htmlFor="email" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.loginScreen.email}</label>
                            <input
                                id="email"
                                name="email"
                                type="email"
                                autoComplete="email"
                                required
                                value={email}
                                onChange={(e) => setEmail(e.target.value)}
                                className={baseInputClasses}
                                placeholder={t.loginScreen.emailPlaceholder}
                            />
                        </div>
                    ) : (
                         <div>
                            <label htmlFor="phone" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.loginScreen.phone}</label>
                            <div className="flex items-center gap-2">
                                <select 
                                    value={selectedCountryCode} 
                                    onChange={(e) => setSelectedCountryCode(e.target.value)}
                                    className={selectClasses}
                                    aria-label="Country code"
                                >
                                    {countryData.map(country => (
                                        <option key={country.code} value={country.code}>
                                            {country.flag} {country.code}
                                        </option>
                                    ))}
                                </select>
                                <input
                                    id="phone"
                                    name="phone"
                                    type="tel"
                                    autoComplete="tel"
                                    required
                                    value={phone}
                                    onChange={(e) => setPhone(e.target.value)}
                                    className={`${baseInputClasses} flex-1`}
                                    placeholder={t.loginScreen.phonePlaceholder}
                                />
                            </div>
                        </div>
                    )}

                    <div>
                        <label htmlFor="password" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.loginScreen.password}</label>
                        <input
                            id="password"
                            name="password"
                            type="password"
                            autoComplete="current-password"
                            required
                            value={password}
                            onChange={(e) => setPassword(e.target.value)}
                            className={baseInputClasses}
                            placeholder={t.loginScreen.passwordPlaceholder}
                        />
                    </div>

                    <div>
                        <button
                            type="submit"
                            className="w-full bg-[--primary-600] text-white font-bold py-3 px-6 rounded-lg shadow-lg hover:bg-[--primary-700] focus:outline-none focus:ring-2 focus:ring-[--primary-500] focus:ring-opacity-75 transition-colors disabled:bg-[--primary-400] disabled:cursor-not-allowed"
                        >
                            {authMode === 'login' ? t.loginScreen.loginButton : t.loginScreen.signupButton}
                        </button>
                    </div>
                </form>
            </div>
        </div>
    );
};

export default LoginScreen;
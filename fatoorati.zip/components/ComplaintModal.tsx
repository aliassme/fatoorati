import React, { useState, useEffect } from 'react';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';
import { submitComplaint } from '../services/supabaseService';
import { XIcon } from './Icons';

interface ComplaintModalProps {
  isOpen: boolean;
  onClose: () => void;
}

const ComplaintModal: React.FC<ComplaintModalProps> = ({ isOpen, onClose }) => {
  const { language } = useSettings();
  const t = translations[language].complaintModal;

  const [subject, setSubject] = useState('');
  const [invoiceNumber, setInvoiceNumber] = useState('');
  const [details, setDetails] = useState('');
  const [isSubmitting, setIsSubmitting] = useState(false);
  const [error, setError] = useState('');

  useEffect(() => {
    if (isOpen) {
      // Reset form on open
      setSubject('');
      setInvoiceNumber('');
      setDetails('');
      setError('');
      setIsSubmitting(false);
    }
  }, [isOpen]);
  
  const handleSubmit = async (e: React.FormEvent) => {
    e.preventDefault();
    if (!subject.trim() || !details.trim()) {
      setError(t.errors.required);
      return;
    }
    setError('');
    setIsSubmitting(true);
    try {
      await submitComplaint({ subject, invoiceNumber, details });
      alert(t.success);
      onClose();
    } catch (err) {
      console.error(err);
      setError(t.error);
    } finally {
      setIsSubmitting(false);
    }
  };

  if (!isOpen) {
    return null;
  }
  
  const inputClasses = "w-full p-3 bg-[--bg-tertiary] text-[--text-primary] border border-[--border-primary] rounded-md focus:ring-2 focus:ring-[--primary-500] focus:border-[--primary-500] outline-none transition";
  
  return (
    <div
      role="dialog"
      aria-modal="true"
      aria-labelledby="complaint-modal-title"
      className="fixed inset-0 z-50 flex items-center justify-center p-4"
    >
      <div className="fixed inset-0 bg-black/60 backdrop-blur-sm" onClick={onClose} aria-hidden="true"></div>
      
      <div className="relative w-full max-w-lg p-6 bg-[--bg-secondary] rounded-2xl shadow-2xl m-4 transform transition-all duration-300 ease-out scale-95 opacity-0 animate-fade-in-scale">
        <header className="flex items-center justify-between pb-4 border-b border-[--border-primary]">
            <h2 id="complaint-modal-title" className="text-xl font-bold text-[--text-primary]">
              {t.title}
            </h2>
            <button onClick={onClose} className="p-1 rounded-full text-[--text-tertiary] hover:bg-[--bg-tertiary] hover:text-[--text-primary] transition-colors">
                <XIcon className="w-6 h-6" />
            </button>
        </header>

        <form onSubmit={handleSubmit} className="mt-6 space-y-6">
            {error && <p className="text-red-400 text-center bg-red-900/50 p-3 rounded-md">{error}</p>}
            <div>
              <label htmlFor="subject" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.subject}</label>
              <input id="subject" type="text" value={subject} onChange={(e) => setSubject(e.target.value)} className={inputClasses} required />
            </div>
            <div>
              <label htmlFor="invoiceNumber" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.invoiceNumber}</label>
              <input id="invoiceNumber" type="text" value={invoiceNumber} onChange={(e) => setInvoiceNumber(e.target.value)} className={inputClasses} />
            </div>
            <div>
                <label htmlFor="details" className="block text-sm font-medium text-[--text-secondary] mb-2">{t.details}</label>
                <textarea id="details" value={details} onChange={(e) => setDetails(e.target.value)} className={`${inputClasses} min-h-[120px]`} required />
            </div>

            <div className="flex justify-end gap-3 pt-4 border-t border-[--border-primary]">
              <button
                type="button"
                onClick={onClose}
                className="px-4 py-2 text-sm font-bold text-[--text-secondary] bg-[--bg-tertiary] rounded-lg hover:bg-[--border-primary] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[--bg-secondary] focus:ring-[--primary-500] transition-colors"
              >
                {t.cancel}
              </button>
              <button
                type="submit"
                disabled={isSubmitting}
                className="px-4 py-2 text-sm font-bold text-white bg-[--primary-600] rounded-lg shadow-md hover:bg-[--primary-700] focus:outline-none focus:ring-2 focus:ring-offset-2 focus:ring-offset-[--bg-secondary] focus:ring-[--primary-500] transition-colors disabled:bg-[--primary-400] disabled:cursor-wait"
              >
                {isSubmitting ? t.submitting : t.submit}
              </button>
            </div>
        </form>
      </div>
      <style>{`
        @keyframes fadeInScale {
            to {
                transform: scale(1);
                opacity: 1;
            }
        }
        .animate-fade-in-scale {
            animation: fadeInScale 0.2s ease-out forwards;
        }
      `}</style>
    </div>
  );
};

export default ComplaintModal;
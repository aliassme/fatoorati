import React from 'react';
import type { View } from '../types';
import { HomeIcon, DocumentTextIcon, ChartBarIcon, CogIcon } from './Icons';
import { useSettings } from '../contexts/SettingsContext';
import { translations } from '../translations';

interface BottomNavProps {
  currentView: View;
  setView: (view: View) => void;
}

const NavLink: React.FC<{
  viewName: View;
  currentView: View;
  setView: (view: View) => void;
  icon: React.ReactNode;
  label: string;
}> = ({ viewName, currentView, setView, icon, label }) => {
  const isActive = currentView === viewName;
  const classes = isActive ? 'text-[--primary-500]' : 'text-[--text-tertiary] hover:text-[--primary-400]';

  return (
    <button
      onClick={() => setView(viewName)}
      className={`flex flex-col items-center justify-center flex-1 p-2 transition-colors ${classes}`}
    >
      <span className="w-6 h-6">{icon}</span>
      <span className="text-xs mt-1">{label}</span>
    </button>
  );
};

const BottomNav: React.FC<BottomNavProps> = ({ currentView, setView }) => {
  const { language } = useSettings();
  const t = translations[language].sidebar;

  return (
    <nav className="md:hidden fixed bottom-0 left-0 right-0 bg-[--bg-secondary] shadow-[0_-2px_10px_rgba(0,0,0,0.1)] flex justify-around border-t border-[--border-primary] pb-[env(safe-area-inset-bottom)]">
      <NavLink
        viewName="dashboard"
        currentView={currentView}
        setView={setView}
        icon={<HomeIcon />}
        label={t.dashboard}
      />
      <NavLink
        viewName="invoices"
        currentView={currentView}
        setView={setView}
        icon={<DocumentTextIcon />}
        label={t.invoices}
      />
      <NavLink
        viewName="reports"
        currentView={currentView}
        setView={setView}
        icon={<ChartBarIcon />}
        label={t.reports}
      />
      <NavLink
        viewName="settings"
        currentView={currentView}
        setView={setView}
        icon={<CogIcon />}
        label={t.settings}
      />
    </nav>
  );
};

export default BottomNav;
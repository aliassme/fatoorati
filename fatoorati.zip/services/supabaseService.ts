// NOTE FOR DEVELOPERS:
// This service uses localStorage to simulate a backend for demonstration purposes.
// It is named `supabaseService.ts` as a placeholder to show where you would
// integrate a real backend like Supabase, Firebase, or your own API.
// To connect to a real backend, you just need to update the functions below
// to make API calls instead of interacting with localStorage.

import type { Invoice, DashboardStats, Complaint, RevenueReport, ReportPeriod, RevenueDataPoint, Language } from '../types';

const INVOICES_KEY = 'invoices';
const INVOICES_SEEDED_KEY = 'invoices_seeded';
const ACCOUNT_DELETION_SCHEDULED_KEY = 'accountDeletionScheduledAt';
const COMPLAINTS_KEY = 'complaints';


// Keys for simulated cloud backup
const CLOUD_BACKUP_KEY = 'fatoorati_cloud_backup';
const LAST_BACKUP_TIMESTAMP_KEY = 'fatoorati_last_backup_timestamp';


const saveStoredInvoices = (invoices: Invoice[]): void => {
  localStorage.setItem(INVOICES_KEY, JSON.stringify(invoices));
};

const seedInvoices = (): Invoice[] => {
    const today = new Date();
    const formatDate = (date: Date) => date.toISOString().split('T')[0];

    const sampleInvoices: Invoice[] = [
        {
            id: 'seed-1',
            clientName: 'John Doe',
            clientEmail: 'john.doe@example.com',
            invoiceNumber: 'INV-2024-001',
            date: formatDate(new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000)), // 15 days ago
            dueDate: formatDate(new Date(today.getTime() + 15 * 24 * 60 * 60 * 1000)), // 15 days from now
            amount: 1500,
            status: 'pending',
        },
        {
            id: 'seed-2',
            clientName: 'Jane Smith',
            clientEmail: 'jane.smith@example.com',
            invoiceNumber: 'INV-2024-002',
            date: formatDate(new Date(today.getTime() - 45 * 24 * 60 * 60 * 1000)), // 45 days ago
            dueDate: formatDate(new Date(today.getTime() - 15 * 24 * 60 * 60 * 1000)), // 15 days ago
            amount: 250.75,
            status: 'overdue',
        },
        {
            id: 'seed-3',
            clientName: 'Innovate Corp',
            clientEmail: 'contact@innovatecorp.com',
            invoiceNumber: 'INV-2024-003',
            date: formatDate(new Date(today.getTime() - 10 * 24 * 60 * 60 * 1000)), // 10 days ago
            dueDate: formatDate(new Date(today.getTime() - 5 * 24 * 60 * 60 * 1000)), // 5 days ago
            amount: 3200,
            status: 'paid',
        },
        {
            id: 'seed-4',
            clientName: 'Tech Solutions Ltd.',
            clientEmail: 'billing@techsolutions.com',
            invoiceNumber: 'INV-2024-004',
            date: formatDate(today),
            dueDate: formatDate(new Date(today.getTime() + 30 * 24 * 60 * 60 * 1000)), // 30 days from now
            amount: 500,
            status: 'draft',
        },
    ];
    saveStoredInvoices(sampleInvoices);
    localStorage.setItem(INVOICES_SEEDED_KEY, 'true');
    return sampleInvoices;
};

const getStoredInvoices = (): Invoice[] => {
  try {
    const hasBeenSeeded = localStorage.getItem(INVOICES_SEEDED_KEY);
    const invoicesJson = localStorage.getItem(INVOICES_KEY);

    if (!hasBeenSeeded && !invoicesJson) {
        return seedInvoices();
    }

    return invoicesJson ? JSON.parse(invoicesJson) : [];
  } catch (error) {
    console.error("Failed to parse invoices from localStorage", error);
    return [];
  }
};


export const getInvoices = async (): Promise<Invoice[]> => {
  await new Promise(res => setTimeout(res, 300));
  return getStoredInvoices().sort((a, b) => new Date(b.date).getTime() - new Date(a.date).getTime());
};

export const getInvoiceById = async (id: string): Promise<Invoice | undefined> => {
    await new Promise(res => setTimeout(res, 200));
    const invoices = getStoredInvoices();
    return invoices.find(invoice => invoice.id === id);
}

export const getDashboardStats = async (): Promise<DashboardStats> => {
    await new Promise(res => setTimeout(res, 200));
    const invoices = getStoredInvoices();

    const totalRevenue = invoices.filter(inv => inv.status === 'paid').reduce((sum, inv) => sum + inv.amount, 0);
    const sentCount = invoices.length;
    const overdueCount = invoices.filter(inv => inv.status === 'overdue').length;

    // Dummy data for "due soon" as it requires more complex date logic
    const dueSoonCount = invoices.filter(inv => inv.status === 'pending').length;


    return { totalRevenue, sentCount, dueSoonCount, overdueCount };
};


export const addInvoice = async (invoiceData: Omit<Invoice, 'id' | 'status'>): Promise<Invoice> => {
  await new Promise(res => setTimeout(res, 500));
  const invoices = getStoredInvoices();
  const newInvoice: Invoice = {
    ...invoiceData,
    id: new Date().toISOString(),
    status: 'pending', // Default status for new invoices
  };
  const updatedInvoices = [...invoices, newInvoice];
  saveStoredInvoices(updatedInvoices);
  return newInvoice;
};

export const updateInvoice = async (id: string, invoiceData: Omit<Invoice, 'id'>): Promise<Invoice> => {
    await new Promise(res => setTimeout(res, 500));
    const invoices = getStoredInvoices();
    let updatedInvoice: Invoice | undefined;
    const updatedInvoices = invoices.map(invoice => {
        if (invoice.id === id) {
            // Keep the original status when updating other details
            updatedInvoice = { ...invoice, ...invoiceData };
            return updatedInvoice;
        }
        return invoice;
    });
    saveStoredInvoices(updatedInvoices);
    if (!updatedInvoice) {
        throw new Error('Invoice not found');
    }
    return updatedInvoice;
}

export const deleteInvoice = async (id: string): Promise<void> => {
  await new Promise(res => setTimeout(res, 500));
  let invoices = getStoredInvoices();
  invoices = invoices.filter(invoice => invoice.id !== id);
  saveStoredInvoices(invoices);
};

export const submitComplaint = async (complaintData: Omit<Complaint, 'id' | 'submittedAt'>): Promise<Complaint> => {
    await new Promise(res => setTimeout(res, 800)); // Simulate network delay
    try {
        const complaints = JSON.parse(localStorage.getItem(COMPLAINTS_KEY) || '[]');
        const newComplaint: Complaint = {
            ...complaintData,
            id: `complaint-${new Date().toISOString()}`,
            submittedAt: new Date().toISOString(),
        };
        localStorage.setItem(COMPLAINTS_KEY, JSON.stringify([...complaints, newComplaint]));
        return newComplaint;
    } catch (e) {
        console.error("Failed to save complaint", e);
        throw new Error("Could not save complaint.");
    }
};

// New functions for account deletion
export const scheduleAccountDeletion = async (): Promise<string> => {
    await new Promise(res => setTimeout(res, 500));
    const deletionDate = new Date();
    deletionDate.setDate(deletionDate.getDate() + 3); // 3-day grace period
    const deletionTimestamp = deletionDate.toISOString();
    localStorage.setItem(ACCOUNT_DELETION_SCHEDULED_KEY, deletionTimestamp);
    return deletionTimestamp;
};

export const cancelAccountDeletion = async (): Promise<void> => {
    await new Promise(res => setTimeout(res, 500));
    localStorage.removeItem(ACCOUNT_DELETION_SCHEDULED_KEY);
};

export const getAccountDeletionStatus = async (): Promise<string | null> => {
    await new Promise(res => setTimeout(res, 100));
    return localStorage.getItem(ACCOUNT_DELETION_SCHEDULED_KEY);
};

export const deleteAllData = async (): Promise<void> => {
    await new Promise(res => setTimeout(res, 500));
    localStorage.removeItem(INVOICES_KEY);
    localStorage.removeItem(ACCOUNT_DELETION_SCHEDULED_KEY);
    localStorage.removeItem(INVOICES_SEEDED_KEY);
};


// Functions for simulated cloud backup
export const backupInvoicesToCloud = async (): Promise<string> => {
    await new Promise(res => setTimeout(res, 1000)); // Simulate network delay
    const invoices = localStorage.getItem(INVOICES_KEY);
    if (!invoices) {
        throw new Error("No invoices to backup.");
    }
    localStorage.setItem(CLOUD_BACKUP_KEY, invoices);
    const timestamp = new Date().toISOString();
    localStorage.setItem(LAST_BACKUP_TIMESTAMP_KEY, timestamp);
    return timestamp;
};

export const restoreInvoicesFromCloud = async (): Promise<Invoice[]> => {
    await new Promise(res => setTimeout(res, 1000)); // Simulate network delay
    const backup = localStorage.getItem(CLOUD_BACKUP_KEY);
    if (!backup) {
        throw new Error("No cloud backup found.");
    }
    localStorage.setItem(INVOICES_KEY, backup);
    return JSON.parse(backup);
};

export const getLastBackupTimestamp = async (): Promise<string | null> => {
    await new Promise(res => setTimeout(res, 100));
    return localStorage.getItem(LAST_BACKUP_TIMESTAMP_KEY);
};

// Function for Reports Page
export const getRevenueReportData = async (period: ReportPeriod, language: Language): Promise<RevenueReport> => {
    await new Promise(res => setTimeout(res, 600)); // Simulate network delay

    const generateDataPoints = (points: number, maxVal: number, isMonthly: boolean = false): RevenueDataPoint[] => {
        if (isMonthly) {
             const monthsEn = ['Jan', 'Feb', 'Mar', 'Apr', 'May', 'Jun', 'Jul', 'Aug', 'Sep', 'Oct', 'Nov', 'Dec'];
             const monthsAr = ['يناير', 'فبراير', 'مارس', 'أبريل', 'مايو', 'يونيو', 'يوليو', 'أغسطس', 'سبتمبر', 'أكتوبر', 'نوفمبر', 'ديسمبر'];
             const months = language === 'ar' ? monthsAr : monthsEn;
             const currentMonth = new Date().getMonth();
             return months.slice(0, currentMonth + 1).map(month => ({
                label: month,
                value: Math.floor(Math.random() * maxVal) + 1000,
             }));
        }
        
        const labelPrefix = language === 'ar' ? 'يوم' : 'Day';
        return Array.from({ length: points }, (_, i) => ({
            label: `${labelPrefix} ${i + 1}`,
            value: Math.floor(Math.random() * maxVal) + 50,
        }));
    };
    
    let data: RevenueDataPoint[] = [];

    switch (period) {
        case 'last7':
            data = generateDataPoints(7, 500, false);
            break;
        case 'last30':
            data = generateDataPoints(30, 800, false);
            break;
        case 'thisYear':
            data = generateDataPoints(12, 5000, true);
            break;
    }

    const totalRevenue = data.reduce((sum, item) => sum + item.value, 0);
    const totalInvoices = data.length;
    const avgInvoiceValue = totalInvoices > 0 ? totalRevenue / totalInvoices : 0;

    return {
        totalRevenue,
        avgInvoiceValue,
        totalInvoices,
        data,
    };
};
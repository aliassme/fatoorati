import React, { useState, useEffect } from 'react';
import Sidebar from './components/Sidebar';
import Dashboard from './components/Dashboard';
import InvoiceForm from './components/InvoiceForm';
import InvoiceList from './components/InvoiceList';
import Reports from './components/Reports';
import Settings from './components/Settings';
import type { View } from './types';
import { useSettings } from './contexts/SettingsContext';
import BottomNav from './components/BottomNav';
import LoginScreen from './components/LoginScreen';

const App: React.FC = () => {
  const [isAuthenticated, setIsAuthenticated] = useState(true);
  const [view, setView] = useState<View>('dashboard');
  const [editingInvoiceId, setEditingInvoiceId] = useState<string | null>(null);
  const { language } = useSettings();

  useEffect(() => {
    // The "invalid state" error suggests a tricky timing issue.
    // Moving registration into a useEffect hook ensures that we only
    // attempt to register the service worker after the React app has
    // mounted and the document is in a stable state.
    if ('serviceWorker' in navigator) {
      // In sandboxed environments, relative paths can be tricky.
      // Constructing a full URL from the current location's origin
      // ensures the service worker is loaded from the correct origin.
      const swUrl = new URL('sw.js', window.location.origin).href;
      navigator.serviceWorker.register(swUrl).then(registration => {
        // ServiceWorker registration successful
      }).catch(err => {
        console.error('ServiceWorker registration failed: ', err);
      });
    }
  }, []); // Empty dependency array ensures this runs only once after the component mounts.
  
  const handleEditInvoice = (id: string) => {
    setEditingInvoiceId(id);
    setView('form');
  };

  const handleLoginSuccess = () => {
    setIsAuthenticated(true);
  };

  if (!isAuthenticated) {
    return <LoginScreen onLoginSuccess={handleLoginSuccess} />;
  }

  const renderView = () => {
    switch (view) {
      case 'invoices':
        return <InvoiceList setView={setView} onEdit={handleEditInvoice} />;
      case 'form':
        return <InvoiceForm setView={setView} invoiceId={editingInvoiceId} setEditingInvoiceId={setEditingInvoiceId} />;
      case 'reports':
        return <Reports />;
      case 'settings':
        return <Settings />;
      case 'dashboard':
      default:
        return <Dashboard setView={setView} onEditInvoice={handleEditInvoice} />;
    }
  };
  
  return (
    <div className="bg-[--bg-primary] min-h-screen text-[--text-primary] flex" dir={language === 'ar' ? 'rtl' : 'ltr'}>
      <Sidebar currentView={view} setView={setView} />
      <main className="flex-1 overflow-x-hidden pb-20 md:pb-0 pt-[env(safe-area-inset-top)]">
        <div key={view} className="fade-in">
          {renderView()}
        </div>
      </main>
      <BottomNav currentView={view} setView={setView} />
    </div>
  );
};

export default App;

# Fatoorati - Elegant Invoice Management App

Fatoorati is a modern, responsive, and customizable invoice management application built with React and Tailwind CSS. It's designed to be a complete solution for freelancers and small businesses to manage their invoices. The application is fully responsive, supports multiple languages (English & Arabic with RTL), themes, and is a Progressive Web App (PWA).

This template is perfect for developers looking for a solid foundation to build their own invoicing application or to integrate into an existing system.

## ✨ Features

- **Dashboard:** At-a-glance overview of key metrics like total revenue, sent invoices, and overdue invoices.
- **Invoice Management:** Create, Read, Update, and Delete (CRUD) invoices.
- **Responsive Design:** A beautiful and functional UI on all devices, from mobile phones to desktops.
- **Theming:**
    - **4 Base Themes:** Light, Dark, Slate, and Ocean.
    - **6 Accent Colors:** Blue, Green, Purple, Orange, Red, and Teal.
- **Localization:** Full support for English (LTR) and Arabic (RTL). Adding new languages is straightforward.
- **PWA Ready:** Installable on mobile and desktop devices for an app-like experience with offline support.
- **Print & Download:** Easily print invoices or download them as HTML files.
- **Local Persistence:** All data is saved in the browser's `localStorage`, making it work without a backend. Easily adaptable to any backend API.
- **Zero Dependencies:** The project uses CDN links for React and Tailwind CSS, making setup incredibly simple.

## 🚀 Tech Stack

- **React 19:** For building the user interface.
- **Tailwind CSS:** For styling the application.
- **TypeScript:** For type safety and better developer experience.
- **No Build Step Needed:** Runs directly in the browser using ES Modules and import maps.

## 📁 Folder Structure

```
.
├── components/         # React components
├── contexts/           # React context providers (e.g., Settings)
├── services/           # Data services (e.g., localStorage logic)
├── App.tsx             # Main application component
├── index.html          # Entry point of the application
├── index.tsx           # React root renderer
├── sw.js               # Service Worker for PWA
├── translations.ts     # Language translation strings
└── types.ts            # TypeScript type definitions
```

## 🔧 Getting Started

No complex setup is required! You can run this project by simply opening the `index.html` file in your browser using a local server.

1.  **Clone the repository:**
    ```bash
    git clone https://your-repository-url.com/
    cd fatoorati-template
    ```
2.  **Serve the files:**
    You can use any simple HTTP server. A popular choice is `live-server`:
    ```bash
    # Install live-server if you don't have it
    npm install -g live-server

    # Run the server
    live-server
    ```
3.  Open your browser and navigate to the provided local URL (e.g., `http://127.0.0.1:8080`).

## 🎨 Customization

### Changing Text and Translations

All UI text is located in `translations.ts`. You can modify the English (`en`) or Arabic (`ar`) translations or add a new language object.

To add a new language:
1.  Add a new language key and translation object in `translations.ts`.
2.  Add the language option to the `Settings` page (`components/Settings.tsx`) and the `Language` type in `types.ts`.

### Changing Theme and Colors

The application's colors are controlled by CSS variables defined in `index.html`.

- **Base Themes (light, dark, etc.):** Modify the `:root.light`, `:root.dark`, etc. selectors.
- **Accent Colors (blue, green, etc.):** Modify the `.theme-blue`, `.theme-green`, etc. selectors. You can easily add new accent color themes by defining a new class with the primary color CSS variables.

The theme and accent color can be changed by the user from the Settings page. The default theme is set in `contexts/SettingsContext.tsx`.

### Changing Currency

The default currency and the list of available currencies can be modified in `types.ts` in the `currencies` object. The default is also set in `contexts/SettingsContext.tsx`.

### Connecting to a Backend

The current data service in `services/supabaseService.ts` uses `localStorage`. To connect to your own backend API:

1.  Modify the functions in `services/supabaseService.ts` (e.g., `getInvoices`, `addInvoice`).
2.  Replace the `localStorage` logic with `fetch` calls or your preferred API client (like Axios) to communicate with your backend.
3.  The functions are `async` and return `Promises`, so the UI will work seamlessly with real API calls.

## 📦 Building for Production

Since this project is designed to run without a build step, "building" for production simply means deploying the files to a web server. You can copy all the project files to any static web host (like Netlify, Vercel, GitHub Pages, or your own server).

---

Thank you for purchasing Fatoorati! We hope you enjoy building with it.

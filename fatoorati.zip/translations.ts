export const translations = {
  ar: {
    sidebar: {
      title: 'فاتورتي',
      dashboard: 'لوحة التحكم',
      invoices: 'الفواتير',
      reports: 'التقارير',
      settings: 'الإعدادات',
      welcome: 'مرحباً',
    },
    loginScreen: {
      welcome: 'مرحبًا بك في فاتورتي',
      subtitle: 'قم بتسجيل الدخول أو إنشاء حساب لإدارة فواتيرك.',
      login: 'تسجيل الدخول',
      signup: 'إنشاء حساب',
      email: 'البريد الإلكتروني',
      phone: 'رقم الجوال',
      password: 'كلمة المرور',
      emailPlaceholder: 'user@example.com',
      passwordPlaceholder: '********',
      phonePlaceholder: '55 123 4567',
      loginButton: 'تسجيل الدخول',
      signupButton: 'إنشاء حساب',
    },
    countries: {
        sa: 'المملكة العربية السعودية',
        ae: 'الإمارات العربية المتحدة',
        qa: 'قطر',
        kw: 'الكويت',
        bh: 'البحرين',
        om: 'عمان',
        us: 'الولايات المتحدة',
        gb: 'المملكة المتحدة',
        in: 'الهند',
        eg: 'مصر',
        de: 'ألمانيا',
        fr: 'فرنسا',
        au: 'أستراليا',
        cn: 'الصين',
        jp: 'اليابان',
        br: 'البرازيل',
        za: 'جنوب أفريقيا',
    },
    dashboard: {
        loading: 'جاري تحميل لوحة التحكم...',
        title: 'لوحة التحكم',
        stats: {
            totalRevenue: { title: 'إجمالي الإيرادات', subtitle: 'المدفوع في آخر 30 يومًا' },
            sentInvoices: { title: 'الفواتير المرسلة', subtitle: 'في آخر 30 يومًا' },
            dueSoon: { title: 'مستحقة قريبًا', subtitle: 'فاتورة مستحقة في الأيام الـ 7 القادمة' },
            overdue: { title: 'متأخرة', subtitle: 'فواتير متأخرة' }
        },
        recentInvoices: {
            title: 'الفواتير الأخيرة',
            subtitle: 'قائمة بأحدث فواتيرك.',
            table: {
                invoice: 'الفاتورة',
                client: 'العميل',
                status: 'الحالة',
                date: 'التاريخ',
                amount: 'المبلغ'
            },
            noInvoices: 'لا توجد فواتير حديثة.'
        }
    },
    invoiceStatus: {
        all: 'الكل',
        paid: 'مدفوعة',
        pending: 'قيد الانتظار',
        overdue: 'متأخرة',
        draft: 'مسودة'
    },
    invoiceList: {
        title: 'الفواتير',
        subtitle: 'إدارة فواتيرك من هنا.',
        sendComplaint: 'أرسل شكوى',
        newInvoice: 'فاتورة جديدة',
        listTitle: 'قائمة الفواتير',
        listSubtitle: 'قائمة بجميع فواتيرك.',
        complaintFeature: 'ميزة الشكاوى قيد التطوير!',
        loading: 'جاري تحميل الفواتير...',
        noInvoices: 'لا يوجد فواتير تطابق هذا الفلتر.',
        emptyState: {
            title: 'لا توجد فواتير بعد',
            subtitle: 'ابدأ بإنشاء فاتورتك الأولى. الأمر لا يستغرق سوى دقيقة.'
        },
        confirmDelete: 'هل أنت متأكد من حذف هذه الفاتورة؟ لا يمكن التراجع عن هذا الإجراء.',
        deleteModalTitle: 'تأكيد الحذف',
        table: {
            invoice: 'الفاتورة',
            client: 'العميل',
            status: 'الحالة',
            issueDate: 'تاريخ الإصدار',
            dueDate: 'تاريخ الاستحقاق',
            amount: 'المبلغ',
            actions: 'الإجراءات'
        },
        actions: {
            edit: 'تعديل',
            print: 'طباعة',
            download: 'تحميل',
            delete: 'حذف',
            cancel: 'إلغاء'
        },
        errors: {
            fetch: 'حدث خطأ أثناء جلب الفواتير',
            delete: 'فشل حذف الفاتورة. يرجى المحاولة مرة أخرى.',
            popup: 'يرجى السماح بالنوافذ المنبثقة لطباعة الفاتورة.'
        }
    },
    complaintModal: {
        title: 'إرسال شكوى',
        subject: 'الموضوع',
        invoiceNumber: 'رقم الفاتورة (اختياري)',
        details: 'تفاصيل الشكوى',
        submit: 'إرسال الشكوى',
        cancel: 'إلغاء',
        submitting: 'جاري الإرسال...',
        success: 'تم إرسال شكواك بنجاح. سنتواصل معك قريباً.',
        error: 'فشل إرسال الشكوى. يرجى المحاولة مرة أخرى.',
        errors: {
            required: 'يرجى ملء الموضوع وتفاصيل الشكوى.',
        },
    },
    invoiceForm: {
        newTitle: 'فاتورة جديدة',
        editTitle: 'تعديل الفاتورة',
        back: 'رجوع إلى الفواتير',
        clientName: 'اسم العميل',
        clientEmail: 'البريد الإلكتروني للعميل',
        invoiceNumber: 'رقم الفاتورة',
        issueDate: 'تاريخ الإصدار',
        dueDate: 'تاريخ الاستحقاق',
        amount: 'المبلغ',
        status: 'الحالة',
        saving: 'جار الحفظ...',
        saveChanges: 'حفظ التعديلات',
        saveInvoice: 'حفظ الفاتورة',
        alerts: {
            updateSuccess: 'تم تعديل الفاتورة بنجاح',
            createSuccess: 'تم إنشاء الفاتورة بنجاح',
        },
        errors: {
            allFields: 'يرجى ملء جميع الحقول',
            load: 'فشل في تحميل بيانات الفاتورة.',
            notFound: (id: string) => `الفاتورة بالمعرف ${id} غير موجودة.`,
            update: 'حدث خطأ أثناء تعديل الفاتورة',
            create: 'حدث خطأ أثناء حفظ الفاتورة'
        }
    },
    invoicePrint: {
        title: 'فاتورة',
        to: 'فاتورة إلى',
        invoiceNo: 'رقم الفاتورة',
        issueDate: 'تاريخ الإصدار',
        dueDate: 'تاريخ الاستحقاق',
        description: 'الوصف',
        amount: 'المبلغ',
        serviceDesc: 'خدمات مقدمة حسب الاتفاق',
        total: 'الإجمالي'
    },
    reports: {
        title: 'ملخص الإيرادات',
        subtitle: 'تحليل تفاعلي لأداء فواتيرك.',
        loading: 'جاري تحميل بيانات التقرير...',
        totalRevenue: 'إجمالي الإيرادات',
        avgInvoiceValue: 'متوسط قيمة الفاتورة',
        totalInvoices: 'إجمالي الفواتير',
        analysis: {
            title: 'تحليل الإيرادات'
        },
        period: {
            label: 'تحديد الفترة',
            last7: 'آخر 7 أيام',
            last30: 'آخر 30 يومًا',
            thisYear: 'هذه السنة'
        },
        chartPlaceholder: 'سيتم عرض مخطط الإيرادات هنا قريبًا.'
    },
    settings: {
        title: 'الإعدادات',
        subtitle: 'إدارة تفضيلات حسابك وإشعاراتك.',
        appearance: {
            title: 'المظهر',
            subtitle: 'تخصيص شكل وألوان التطبيق.',
            theme: { label: 'المظهر العام', light: 'فاتح', dark: 'داكن', slate: 'رمادي', ocean: 'أزرق' },
            primaryColor: 'اللون الأساسي'
        },
        languageRegion: {
            title: 'اللغة والمنطقة',
            subtitle: 'اختر اللغة والعملة المفضلة لديك.',
            language: 'اللغة',
            currency: 'العملة'
        },
        notifications: {
            title: 'الإشعارات',
            subtitle: 'اختر الإشعارات التي ترغب في تلقيها.',
            invoiceUpdates: { title: 'تحديثات الفواتير', subtitle: 'تلقي إشعارات عند دفع الفواتير أو تأخرها.' },
            weeklySummary: { title: 'ملخصات أسبوعية', subtitle: 'الحصول على ملخص أسبوعي لنشاط الفواتير الخاص بك.' },
            promotions: { title: 'العروض الترويجية', subtitle: 'تلقي إشعارات حول الميزات والخصومات الجديدة.' }
        },
        cloudBackup: {
            title: 'النسخ الاحتياطي السحابي',
            subtitle: 'مزامنة بياناتك مع السحابة بشكل آمن للوصول إليها من أي مكان.',
            syncing: 'جاري المزامنة...',
            lastBackup: {
                title: 'آخر نسخ احتياطي:',
                never: 'لم يتم بعد'
            },
            backup: {
                title: 'النسخ الاحتياطي إلى السحابة',
                subtitle: 'حفظ نسخة من بيانات فواتيرك الحالية في السحابة.',
                button: 'النسخ الاحتياطي الآن',
                success: 'تم نسخ بياناتك احتياطياً إلى السحابة بنجاح.',
                error: 'فشل النسخ الاحتياطي إلى السحابة. يرجى المحاولة مرة أخرى.'
            },
            restore: {
                title: 'الاستعادة من السحابة',
                subtitle: 'استعادة بياناتك من آخر نسخة احتياطية سحابية. سيتم استبدال البيانات الحالية.',
                button: 'الاستعادة الآن',
                confirm: 'هل أنت متأكد؟ سيتم استبدال جميع بيانات الفواتير الحالية بآخر نسخة احتياطية سحابية.',
                success: 'تم استعادة البيانات بنجاح. سيتم تحديث التطبيق.',
                error: 'فشل استعادة البيانات. قد لا يكون هناك نسخة احتياطية متاحة.'
            }
        },
        support: {
            title: 'الدعم الفني',
            subtitle: 'هل تحتاج للمساعدة؟ تواصل مع فريق الدعم لدينا.',
            button: 'الدعم'
        },
        deleteAccount: {
            title: 'حذف الحساب',
            loading: 'جاري التحقق من حالة الحساب...',
            scheduledInfo: (date: string) => `حسابك مجدول للحذف النهائي في: <span class="font-bold text-yellow-400">${date}</span>.<br />يمكنك التراجع عن هذا الإجراء قبل انقضاء الموعد.`,
            cancelButton: 'تراجع عن الحذف',
            description: 'سيتم جدولة حذف حسابك وجميع بياناتك (الفواتير) نهائياً بعد 3 أيام. لا يمكن التراجع عن هذا الإجراء بعد انتهاء فترة السماح.',
            requestButton: 'اطلب حذف الحساب',
            confirm: 'هل أنت متأكد من رغبتك في حذف حسابك؟ سيتم حذف جميع بياناتك نهائياً بعد 3 أيام.',
            alerts: {
                scheduled: 'تم جدولة حسابك للحذف. يمكنك التراجع خلال 3 أيام.',
                error: 'حدث خطأ أثناء جدولة حذف الحساب.',
                cancelled: 'تم إلغاء عملية حذف الحساب بنجاح.',
                cancelError: 'حدث خطأ أثناء إلغاء حذف الحساب.',
                success: 'وفقًا لطلبك، تم حذف حسابك وجميع بياناتك نهائياً.'
            }
        },
        logout: {
            title: 'تسجيل الخروج',
            subtitle: 'الخروج من حسابك الحالي.',
            button: 'تسجيل الخروج'
        }
    }
  },
  en: {
    sidebar: {
      title: 'Fatoorati',
      dashboard: 'Dashboard',
      invoices: 'Invoices',
      reports: 'Reports',
      settings: 'Settings',
      welcome: 'Welcome',
    },
    loginScreen: {
      welcome: 'Welcome to Fatoorati',
      subtitle: 'Log in or create an account to manage your invoices.',
      login: 'Log In',
      signup: 'Sign Up',
      email: 'Email',
      phone: 'Mobile Number',
      password: 'Password',
      emailPlaceholder: 'user@example.com',
      passwordPlaceholder: '********',
      phonePlaceholder: '55 123 4567',
      loginButton: 'Log In',
      signupButton: 'Sign Up',
    },
    countries: {
        sa: 'Saudi Arabia',
        ae: 'United Arab Emirates',
        qa: 'Qatar',
        kw: 'Kuwait',
        bh: 'Bahrain',
        om: 'Oman',
        us: 'United States',
        gb: 'United Kingdom',
        in: 'India',
        eg: 'Egypt',
        de: 'Germany',
        fr: 'France',
        au: 'Australia',
        cn: 'China',
        jp: 'Japan',
        br: 'Brazil',
        za: 'South Africa',
    },
    dashboard: {
        loading: 'Loading dashboard...',
        title: 'Dashboard',
        stats: {
            totalRevenue: { title: 'Total Revenue', subtitle: 'Paid in the last 30 days' },
            sentInvoices: { title: 'Sent Invoices', subtitle: 'In the last 30 days' },
            dueSoon: { title: 'Due Soon', subtitle: 'Invoices due in the next 7 days' },
            overdue: { title: 'Overdue', subtitle: 'Overdue invoices' }
        },
        recentInvoices: {
            title: 'Recent Invoices',
            subtitle: 'A list of your most recent invoices.',
            table: {
                invoice: 'Invoice',
                client: 'Client',
                status: 'Status',
                date: 'Date',
                amount: 'Amount'
            },
            noInvoices: 'No recent invoices found.'
        }
    },
    invoiceStatus: {
        all: 'All',
        paid: 'Paid',
        pending: 'Pending',
        overdue: 'Overdue',
        draft: 'Draft'
    },
    invoiceList: {
        title: 'Invoices',
        subtitle: 'Manage your invoices from here.',
        sendComplaint: 'Send Complaint',
        newInvoice: 'New Invoice',
        listTitle: 'Invoice List',
        listSubtitle: 'A list of all your invoices.',
        complaintFeature: 'Complaint feature is under development!',
        loading: 'Loading invoices...',
        noInvoices: 'No invoices match this filter.',
        emptyState: {
            title: 'No Invoices Yet',
            subtitle: 'Get started by creating your first invoice. It only takes a minute.'
        },
        confirmDelete: 'Are you sure you want to delete this invoice? This action cannot be undone.',
        deleteModalTitle: 'Confirm Deletion',
        table: {
            invoice: 'Invoice',
            client: 'Client',
            status: 'Status',
            issueDate: 'Issue Date',
            dueDate: 'Due Date',
            amount: 'Amount',
            actions: 'Actions'
        },
        actions: {
            edit: 'Edit',
            print: 'Print',
            download: 'Download',
            delete: 'Delete',
            cancel: 'Cancel'
        },
        errors: {
            fetch: 'An error occurred while fetching invoices.',
            delete: 'Failed to delete the invoice. Please try again.',
            popup: 'Please allow pop-ups to print the invoice.'
        }
    },
    complaintModal: {
        title: 'Submit a Complaint',
        subject: 'Subject',
        invoiceNumber: 'Invoice Number (Optional)',
        details: 'Complaint Details',
        submit: 'Submit Complaint',
        cancel: 'Cancel',
        submitting: 'Submitting...',
        success: 'Your complaint has been submitted successfully. We will get back to you soon.',
        error: 'Failed to submit complaint. Please try again.',
        errors: {
            required: 'Please fill in the subject and complaint details.',
        },
    },
    invoiceForm: {
        newTitle: 'New Invoice',
        editTitle: 'Edit Invoice',
        back: 'Back to Invoices',
        clientName: 'Client Name',
        clientEmail: 'Client Email',
        invoiceNumber: 'Invoice Number',
        issueDate: 'Issue Date',
        dueDate: 'Due Date',
        amount: 'Amount',
        status: 'Status',
        saving: 'Saving...',
        saveChanges: 'Save Changes',
        saveInvoice: 'Save Invoice',
        alerts: {
            updateSuccess: 'Invoice updated successfully.',
            createSuccess: 'Invoice created successfully.',
        },
        errors: {
            allFields: 'Please fill in all fields.',
            load: 'Failed to load invoice data.',
            notFound: (id: string) => `Invoice with ID ${id} not found.`,
            update: 'An error occurred while updating the invoice.',
            create: 'An error occurred while saving the invoice.'
        }
    },
    invoicePrint: {
        title: 'Invoice',
        to: 'Invoice To',
        invoiceNo: 'Invoice Number',
        issueDate: 'Issue Date',
        dueDate: 'Due Date',
        description: 'Description',
        amount: 'Amount',
        serviceDesc: 'Services rendered as per agreement',
        total: 'Total'
    },
    reports: {
        title: 'Revenue Summary',
        subtitle: 'An interactive analysis of your invoice performance.',
        loading: 'Loading report data...',
        totalRevenue: 'Total Revenue',
        avgInvoiceValue: 'Avg. Invoice Value',
        totalInvoices: 'Total Invoices',
        analysis: {
            title: 'Revenue Analysis'
        },
        period: {
            label: 'Select Period',
            last7: 'Last 7 Days',
            last30: 'Last 30 Days',
            thisYear: 'This Year'
        },
        chartPlaceholder: 'A revenue chart will be displayed here soon.'
    },
    settings: {
        title: 'Settings',
        subtitle: 'Manage your account and notification preferences.',
        appearance: {
            title: 'Appearance',
            subtitle: 'Customize the look and feel of the app.',
            theme: { label: 'Theme', light: 'Light', dark: 'Dark', slate: 'Slate', ocean: 'Ocean' },
            primaryColor: 'Primary Color'
        },
        languageRegion: {
            title: 'Language & Region',
            subtitle: 'Choose your preferred language and currency.',
            language: 'Language',
            currency: 'Currency'
        },
        notifications: {
            title: 'Notifications',
            subtitle: 'Choose which notifications you want to receive.',
            invoiceUpdates: { title: 'Invoice Updates', subtitle: 'Receive notifications for paid or overdue invoices.' },
            weeklySummary: { title: 'Weekly Summaries', subtitle: 'Get a weekly summary of your invoice activity.' },
            promotions: { title: 'Promotions', subtitle: 'Receive notifications about new features and discounts.' }
        },
        cloudBackup: {
            title: 'Cloud Backup',
            subtitle: 'Sync your data securely with the cloud to access it anywhere.',
            syncing: 'Syncing...',
            lastBackup: {
                title: 'Last backup:',
                never: 'Never'
            },
            backup: {
                title: 'Backup to Cloud',
                subtitle: 'Save a snapshot of your current invoice data to the cloud.',
                button: 'Backup Now',
                success: 'Your data has been successfully backed up to the cloud.',
                error: 'Failed to backup to the cloud. Please try again.'
            },
            restore: {
                title: 'Restore from Cloud',
                subtitle: 'Restore your data from the latest cloud backup. This will overwrite local data.',
                button: 'Restore Now',
                confirm: 'Are you sure? This will overwrite all current invoice data with your latest cloud backup.',
                success: 'Data restored successfully. The app will now refresh.',
                error: 'Failed to restore data. No cloud backup may be available.'
            }
        },
        support: {
            title: 'Technical Support',
            subtitle: 'Need help? Contact our support team.',
            button: 'Support'
        },
        deleteAccount: {
            title: 'Delete Account',
            loading: 'Checking account status...',
            scheduledInfo: (date: string) => `Your account is scheduled for permanent deletion on: <span class="font-bold text-yellow-400">${date}</span>.<br />You can undo this action before the time is up.`,
            cancelButton: 'Cancel Deletion',
            description: 'Your account and all its data (invoices) will be scheduled for permanent deletion after 3 days. This action cannot be undone after the grace period.',
            requestButton: 'Request Account Deletion',
            confirm: 'Are you sure you want to delete your account? All your data will be permanently deleted after 3 days.',
            alerts: {
                scheduled: 'Your account has been scheduled for deletion. You can cancel within 3 days.',
                error: 'An error occurred while scheduling account deletion.',
                cancelled: 'Account deletion has been successfully cancelled.',
                cancelError: 'An error occurred while cancelling account deletion.',
                success: 'As per your request, your account and all its data have been permanently deleted.'
            }
        },
        logout: {
            title: 'Log Out',
            subtitle: 'Log out of your current account.',
            button: 'Log Out'
        }
    }
  }
};
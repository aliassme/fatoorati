import React, { createContext, useState, useContext, useEffect, useMemo, ReactNode } from 'react';
import type { Language, Theme, Currency, PrimaryColor } from '../types';
import { currencies } from '../types';

interface SettingsContextType {
  language: Language;
  setLanguage: (lang: Language) => void;
  theme: Theme;
  setTheme: (theme: Theme) => void;
  currency: Currency;
  setCurrency: (currency: Currency) => void;
  primaryColor: PrimaryColor;
  setPrimaryColor: (color: PrimaryColor) => void;
  // FIX: Update formatCurrency type definition to allow an optional options argument. This resolves an error in Reports.tsx where a second argument was passed for formatting.
  formatCurrency: (amount: number, options?: Intl.NumberFormatOptions) => string;
}

const SettingsContext = createContext<SettingsContextType | undefined>(undefined);

export const SettingsProvider: React.FC<{ children: ReactNode }> = ({ children }) => {
  const [language, setLanguage] = useState<Language>(() => (localStorage.getItem('language') as Language) || 'en');
  const [theme, setTheme] = useState<Theme>(() => (localStorage.getItem('theme') as Theme) || 'dark');
  const [currency, setCurrency] = useState<Currency>(() => (localStorage.getItem('currency') as Currency) || 'USD');
  const [primaryColor, setPrimaryColor] = useState<PrimaryColor>(() => (localStorage.getItem('primaryColor') as PrimaryColor) || 'blue');

  useEffect(() => {
    localStorage.setItem('language', language);
    document.documentElement.lang = language;
    document.documentElement.dir = language === 'ar' ? 'rtl' : 'ltr';
  }, [language]);

  useEffect(() => {
    localStorage.setItem('theme', theme);
    document.documentElement.classList.remove('light', 'dark', 'slate', 'ocean');
    document.documentElement.classList.add(theme);
  }, [theme]);
  
  useEffect(() => {
    localStorage.setItem('primaryColor', primaryColor);
    document.body.classList.remove('theme-blue', 'theme-green', 'theme-purple', 'theme-orange', 'theme-red', 'theme-teal');
    document.body.classList.add(`theme-${primaryColor}`);
  }, [primaryColor]);

  useEffect(() => {
    localStorage.setItem('currency', currency);
  }, [currency]);

  // FIX: Update formatCurrency implementation to accept an optional options object. This allows for more flexible currency formatting, like controlling fraction digits as needed in Reports.tsx.
  const formatCurrency = useMemo(() => {
    return (amount: number, options?: Intl.NumberFormatOptions) => {
      const defaultOptions: Intl.NumberFormatOptions = {
        style: 'currency',
        currency: currency,
        currencyDisplay: 'symbol'
      };
      return new Intl.NumberFormat(language === 'ar' ? 'ar-SA' : 'en-US', {
        ...defaultOptions,
        ...options,
      }).format(amount);
    };
  }, [currency, language]);

  const value = {
    language,
    setLanguage,
    theme,
    setTheme,
    currency,
    setCurrency,
    primaryColor,
    setPrimaryColor,
    formatCurrency,
  };

  return <SettingsContext.Provider value={value}>{children}</SettingsContext.Provider>;
};

export const useSettings = (): SettingsContextType => {
  const context = useContext(SettingsContext);
  if (context === undefined) {
    throw new Error('useSettings must be used within a SettingsProvider');
  }
  return context;
};
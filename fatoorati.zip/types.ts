export type InvoiceStatus = 'paid' | 'pending' | 'overdue' | 'draft';

export interface Invoice {
  id: string;
  clientName: string;
  clientEmail: string;
  invoiceNumber: string;
  date: string; // Issue Date
  dueDate: string; // Due Date
  amount: number;
  status: InvoiceStatus;
}

export type View = 'dashboard' | 'invoices' | 'form' | 'reports' | 'settings';

export interface DashboardStats {
  totalRevenue: number;
  sentCount: number;
  dueSoonCount: number;
  overdueCount: number;
}

export interface Complaint {
  id: string;
  subject: string;
  invoiceNumber?: string;
  details: string;
  submittedAt: string;
}

// New types for settings
export type Language = 'ar' | 'en';
export type Theme = 'light' | 'dark' | 'slate' | 'ocean';
export type PrimaryColor = 'blue' | 'green' | 'purple' | 'orange' | 'red' | 'teal';

export type Currency = 'SAR' | 'AED' | 'QAR' | 'KWD' | 'BHD' | 'OMR' | 'USD';

export const currencies: Record<Currency, { name: string; symbol: string }> = {
    SAR: { name: "Saudi Riyal", symbol: "ر.س" },
    AED: { name: "UAE Dirham", symbol: "د.إ" },
    QAR: { name: "Qatari Riyal", symbol: "ر.ق" },
    KWD: { name: "Kuwaiti Dinar", symbol: "د.ك" },
    BHD: { name: "Bahraini Dinar", symbol: "د.ب" },
    OMR: { name: "Omani Rial", symbol: "ر.ع" },
    USD: { name: "US Dollar", symbol: "$" },
};

// Types for Country Selector
export type CountryNameKey =
  | 'sa' | 'ae' | 'qa' | 'kw' | 'bh' | 'om' // Gulf Countries
  | 'us' | 'gb' | 'in' | 'eg' | 'de' | 'fr' | 'au' | 'cn' | 'jp' | 'br' | 'za'; // International Countries

export interface Country {
  nameKey: CountryNameKey;
  code: string;
  flag: string;
}

export const countryData: Country[] = [
  // Gulf Countries
  { nameKey: 'sa', code: '+966', flag: '🇸🇦' },
  { nameKey: 'ae', code: '+971', flag: '🇦🇪' },
  { nameKey: 'qa', code: '+974', flag: '🇶🇦' },
  { nameKey: 'kw', code: '+965', flag: '🇰🇼' },
  { nameKey: 'bh', code: '+973', flag: '🇧🇭' },
  { nameKey: 'om', code: '+968', flag: '🇴🇲' },
  // International Countries
  { nameKey: 'us', code: '+1', flag: '🇺🇸' },
  { nameKey: 'gb', code: '+44', flag: '🇬🇧' },
  { nameKey: 'in', code: '+91', flag: '🇮🇳' },
  { nameKey: 'eg', code: '+20', flag: '🇪🇬' },
  { nameKey: 'de', code: '+49', flag: '🇩🇪' },
  { nameKey: 'fr', code: '+33', flag: '🇫🇷' },
  { nameKey: 'au', code: '+61', flag: '🇦🇺' },
  { nameKey: 'cn', code: '+86', flag: '🇨🇳' },
  { nameKey: 'jp', code: '+81', flag: '🇯🇵' },
  { nameKey: 'br', code: '+55', flag: '🇧🇷' },
  { nameKey: 'za', code: '+27', flag: '🇿🇦' },
];

// Types for Reports Page
export type ReportPeriod = 'last7' | 'last30' | 'thisYear';

export interface RevenueDataPoint {
  label: string;
  value: number;
}

export interface RevenueReport {
  totalRevenue: number;
  avgInvoiceValue: number;
  totalInvoices: number;
  data: RevenueDataPoint[];
}